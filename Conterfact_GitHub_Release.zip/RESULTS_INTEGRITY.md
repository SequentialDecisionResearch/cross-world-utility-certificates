# Experiment archive validation record

## Experimental execution

- Run date: 2026-10-24.
- Python 3.12.14; NumPy 2.3.5; SciPy 1.17.0; Matplotlib 3.10.8.
- E7: 32 distinct conditions, 1,000 simulations each, 32,000 individual records.
- E8: 6 conditions, 400 simulations each, 2,400 individual records.
- E9: 40 distinct conditions, 300 simulations each, 12,000 individual records.
- Total new simulation records: **46,400**. Each record remains accessible in aggregate and its corresponding condition file.
- Seeds are explicitly recorded in every replicate and each cached condition's JSON metadata; design parameters in `results/design.json`.

## Completed checks

1. Mathematical identity tests for structural value-gap signs, observational equivalence, empirical-radius formula, LP geometric margin, continuous-parameter feasible projections, Bernoulli KL, cost-normalized information LP, and the model-class distinction between bounds and real-world guarantees.
2. Input-independent acquisition test: every E9 policy is feasible without being told the true structural model.
3. Reconciliation by the independent auditor `experiment_code/audit_output.py`: all replicate IDs, summaries, budgets, sample batches, censoring, signs, wrong-sign/coverage implications, every checkpoint's contents and 7 PNG signatures.
4. E9 `I_star` LP independently compared with a dense 4,001-point cost-fraction grid for all 8 true models.
5. Historical archive: `cd historical_source && python reproduce.py --verify` successfully verified SHA-256 hashes for 39 original files, all theory/legacy/projection checks, 12,000 legacy single-run records, and 3,840 legacy adaptive records.
6. Output regeneration: rerunning the full E7--E9 driver with unchanged inputs reports all 78 cells `cached` and reconciles all original simulation counts.

## Fault discovered and fixed before delivery

An initial checkpoint implementation used `Path.with_suffix()` on names containing a decimal (`q0.25`), which could collapse two cells' cache filenames. The independent audit detected an incorrect checkpoint count. The implementation was fixed to append `.csv`/`.json` without changing the base key; a regression test was added; the 46,400 simulations were **rerun at full scale**, obsolete checkpoint files were quarantined outside this final archive, and the final 78 per-condition checkpoints passed the independent reconciliation. The original historical source files were not changed.

## Scope of statistical claims

E7 noninformative-feature impossibility is a population law statement, while reported forced-error percentages and certifying rates are Monte Carlo estimates. E8's numerical sufficient-size thresholds are *sufficient*, not estimated minimax bounds. E9's estimated adaptive-uniform cost contrast is model-dependent, unpaired and exploratory. The KL information lower-bound formula requires *uniform* error and abstention conditions, which finite counts alone do not establish. Historical-vs-new costs are not equivalent due to changed model classes and stopping budgets.

## Final archive audit

The final ZIP is independently tested with a ZIP CRC check, extraction to a separate directory, unit tests, the simulator's `--verify-only`, and the independent CSV auditor. Content hash manifest `MANIFEST_SHA256.txt` verifies member bytes. No E7--E9 simulation or output table is represented as independently collected real-world evidence.
