# Decision Certificates for Cross-World Utilities — upgraded reproducible research package

**Status:** Revised English manuscript and controlled synthetic evidence only. It has **not** been independently peer reviewed, accepted by a venue, uploaded to arXiv, or posted to GitHub. The paper's narrower internal title intentionally differs from the two user-requested external filenames.

## Package inventory

- `paper.tex`: complete paper with assumptions, Theorems 2/5/8/10/11, proofs, the implemented restricted witness selector, exploratory results, nine genuine generated figures, and limitations.
- `baseline_reference/summary.json` and `baseline_reference/replicates.csv`: immutable baseline bytes from the supplied predecessor, permitting an entirely **offline, portable** original-results regression test.
- `model.py`, `theory_checks.py`, `legacy_two_stage_checks.py`: original three-stage SCM, original theorem and independent legacy audits; the original 12,000-repetition CSV is byte-identical to the supplied predecessor.
- `run_experiments.py`: **original** 12 conditions × 1,000 repetitions (seed 260917, synthetic budget 12,000). The original static `targeted` baseline remains labeled STATIC; the implemented linked-offset Witness selector is separate. Algorithm 1 is a general certification protocol, not a claim that arbitrary finite-SCM acquisition has been implemented.
- `dynamic_acquisition.py`: **new** adaptive witness/KL-per-price selection with predictable every-tenth-batch fair exploration, a known two-channel linked calibration mechanism and unknown nuisance `h`; 4 worlds × 4 rules × 240 independently seeded repetitions = 3,840 records. Includes exact two-dimensional confidence projection and independent SciPy LP reference solver.
- `hard_cases.py`: **new** six difficult/endpoint coupling values × 500 = 3,000 repetitions and four correct-calibration boundary conditions × 500 = 2,000 repetitions.
- `upgrade_checks.py`: rigorous source/CSV reconciliation, independently enumerated conditional sensor means, **1,000** random analytic-projection-versus-independent-LP comparisons, feasible extremal witnesses, budget accounting, 9 figure checks and displayed Monte Carlo uncertainty.
- `results/summary.json`, `replicates.csv`: predecessor original study; `results/dynamic_summary.json`, `dynamic_replicates.csv`, `dynamic_trace.json`: adaptive/composite study; `results/hard_summary.json`, `hard_replicates.csv`: margin/boundary study. Three console logs accompany their runs.
- `figures/`: **nine** actual analytic or Monte Carlo generated PNGs. Figure 1 and the LP figure are analytical/deterministic; all others have traceable raw synthetic records.
- `REVISION_AUDIT.md`: expert-feedback-to-change-to-test matrix and a detailed list of uncompleted tasks.
- `ARXIV_SUBMISSION_INSTRUCTIONS.txt`: instructions for placing the TeX tree and companion data archive at submission.
- `arxiv_source/`: arXiv-ready `paper.tex`, nine figures, and `anc/Evidence_Sufficient_Counterfactual_RL_Data.zip` containing this release's non-TeX reproducibility materials. Archive **the contents of this directory** as the arXiv TeX submission; the ancillary ZIP is only publicly downloadable if the `anc/` directory is actually included. No arXiv upload or public repository is claimed.

## One-command offline reproduction

From the root of the extracted companion ZIP or the arXiv ancillary ZIP, use `python reproduce.py --verify` to check every archived file digest, the documented seed rules, and executable theorem/numeric audits. Use `python reproduce.py --rerun` to regenerate all reported synthetic output files from the fixed seeded runners before checking them. The latter is a full CPU run, not a quick smoke test.

Python 3.10+, LaTeX (`latexmk`, `pdflatex` and standard packages), and `pip install -r requirements.txt` are needed. From the root of the extracted archive:

```bash
python theory_checks.py
python legacy_two_stage_checks.py
python run_experiments.py
python dynamic_acquisition.py
python hard_cases.py
python upgrade_checks.py
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
```

The three experiment runners each use a **distinct per-cell seed rule**, detailed in `SEED_RULES.json`: the original study uses base `260917`, dynamic cells `270000+10007*i+997*j`, hard margins `280000+101*j`, and calibration-boundary cells `290000+109*j`. They do **not** all share a single generator seed. Each runner regenerates its **own** results, and the nine figures arise from their corresponding runners; `paper.tex` compiles the figures. Quick smoke runs use `--quick` and write to *separate* `results_quick/`, `figures_quick/` folders; quick results are **not** reported in the PDF. The full suite requires only local CPU and does not contact websites. Under other NumPy/SciPy/matplotlib versions, visual raster bytes and pseudorandom streams can differ; reconcile scientific quantities, seeds, and software versions rather than assuming cross-platform byte-identical PNGs.

## Evidence provenance and nonclaims

A total of **20,840** independently drawn synthetic replication records (per-cell seeded streams) are present: 12,000 original + 3,840 composite + 5,000 hard/boundary. All reported sample means, rates and costs are from actual runs, not placeholders. A 0/240 or 0/500 observed wrong-sign count does not prove a universal 5% error bound. The formal validity is conditional on the stipulated true structural and proxy kernels. The linked calibration offset used by the dynamic benchmark is a **synthetic design assumption**, not an observed property of any real sensor.

No real-world auxiliary proxy calibration, held-out human dataset, resettable-unit study, delayed-feedback study, large learned policy class, fixed validation-fee sweep, independent multi-machine replication, full systematic plagiarism/priority audit, external expert proof review, public GitHub repository, or commit SHA is claimed. The manuscript contains no fabricated GitHub URL or commit identifier. The same reproducibility data are also packaged under `arxiv_source/anc/` with a SHA-256 inventory; no public URL, DOI or Git commit is claimed. A PDF-only arXiv upload does not contain this attachment and requires revising the manuscript availability statement. The ancillary ZIP digest identifying the exact release appears in the PDF. A real public versioned archive may be supplied later; GitHub is optional.

## Final editorial freeze and open items

The final revision corrects two PDF text errors (the static-vs-implemented Witness contradiction and an unclosed quotation mark), labels Algorithm 1 as a general protocol, and states the linked-offset model as the *only* implemented witness acquisition specialization. The post-review 240-repetition tests remain exploratory. All existing 20,840 synthetic records and nine original figure rasters are retained; no additional experiments or new empirical claims have been inserted. The E6 single-proxy false-calibration stress test is **not** evidence about a false linked-offset $h$ mechanism. Such a test was not run and is explicitly listed as unexecuted.

A public repository or commit SHA does not yet exist; the arXiv-ready TeX tree now includes a separately downloadable-on-posting ancillary research-data ZIP with a recorded SHA-256 digest. Submit the complete `arxiv_source/` tree (including `anc/`) or adjust the manuscript's availability claim before a PDF-only posting. Independent proof/priority review and independent-machine replication also remain open. See `REVISION_AUDIT.md` for itemized checks and the final packaging verification.

## 2026-09-18 final PDF/source synchronization

This companion source ZIP has been synchronized to the separately delivered
`Evidence_Sufficient_Counterfactual_RL_Manuscript.pdf` after the last editorial
preflight. Both `paper.tex` and `arxiv_source/paper.tex` now use the same revised
TeX as `arxiv_submission_source_ready.zip`: the original static-study description
uses a **predeclared** feature-stream count `M`, Theorem 10 and all related
references consistently use `\beta_{\\mathrm{abs}}`, bibliography floats no
longer interrupt a paragraph, and the PDF author is set. The complete
`arxiv_source/` directory contains the current TeX and unchanged figures and
ancillary data; package its **contents**, not this entire research ZIP, for arXiv.

All 20,840 existing synthetic-replication records, the nine figure rasters,
Python scripts, and `arxiv_source/anc/` are byte-for-byte unchanged from the
submitted predecessor source ZIP. The ancillary SHA-256 named in the PDF
therefore remains valid. Only manuscript TeX, companion documentation, and
this outer ZIP's `MANIFEST.sha256` and root `DATA_MANIFEST.sha256` were updated. Verify the outer manifest with
`sha256sum -c MANIFEST.sha256` after extraction and the unchanged ancillary
with `python reproduce.py --verify` from the extracted `anc/` archive.
