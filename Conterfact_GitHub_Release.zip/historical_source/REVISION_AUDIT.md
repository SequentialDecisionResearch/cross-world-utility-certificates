# Itemized independent-of-the-narrative revision audit

**Inputs actually supplied this turn:** 12-page `Decision Certificates for Cross-World Utilities...` PDF at `/mnt/data/415a69c2-226e-4bd1-ba2a-25f2cec7c96c.pdf` and its 16-item code/results ZIP at `/mnt/data/2ea7c82d-1079-4c35-bc26-9a99c31325f2.zip`. **Outputs at the earlier upgrade stage:** the requested two external filenames, with a 16-page PDF and a self-contained ZIP. The subsequent arXiv preflight PDF is 17 pages; its unchanged simulations are separately verified below. All numbers below are synthetic. This is a computational and mathematical self-audit, not independent peer review, a promise of originality, or acceptance.

## Reviewer recommendation → revision → check

| ID | Specific feedback / risk | Actual change | Audit evidence / status |
|---|---|---|---|
| 1 | Actual Algorithm 1 purchase heuristic previously not implemented | Explicit two-parameter linked-proxy $(q,h)$ model, extremal witnesses, symmetric Bernoulli KL / synthetic price and deterministic every-tenth-batch fair exploration; exact formula and executable code added. | `dynamic_acquisition.py`: 16 world × policy cells / **3,840** independent records; `results/dynamic_trace.json`, per-run `n_plus,n_minus`; `upgrade_checks.py` checks choice, cost and endpoints. **Done for this restricted model only; general finite-SCM witness solver not done.** |
| 2 | A single strong fixed channel makes purported adaptivity trivial | Added two opposite-nuisance sensors, with $m_\pm=.08+.8(q\pm h)$, unequal prices, four asymmetric worlds, static plus/minus and alternating baselines. | 286 independent enumerated sensor-kernel probability checks, empirical channel fractions/witness switching; formula identifies $q$ from *both* population means. **Done, synthetic joint-calibration symmetry unvalidated in reality.** |
| 3 | Avoid invented optimality and report negative findings | Paper compares unconditional budget-censored cost and abstention, and reports witness **more expensive** in the $(q,h)=(.32,-.05)$ cell. | Witness vs uniform RMC: $(.28,.05)$ 129,864 vs 138,010; $(.32,-.05)$ 136,087 vs 133,902. Independent-replicate MC SE for Uniform-minus-Witness: 2,211.5 and 2,520.4 respectively. **Done; neither universal superiority nor statistical superiority in every cell claimed.** |
| 4 | Harder decision margin than $q\in\{.2,.4\}$ | Additional $q=.20,.25,.28,.32,.35,.40$ grid, with exact calibrated strong proxy, cap 180,000, 100-observation batches, 500 repetitions each. | `hard_cases.py`, `results/hard_replicates.csv`: signatures 500,500,498,497,500,500; restricted costs 3,072; 13,713; 98,365; 99,874; 13,834; 3,022; zero observed wrong signs. **Done; these selected cells do not establish an exact asymptotic rate.** |
| 5 | Calibration range truth at boundary | Added $(\alpha,\beta)=(.85,.95),(.95,.85)$ at $q=.2,.4$, using correct $[.85,.95]^2$ envelope, 500 repetitions each. | Signed 500,0,0,500 respectively; zero observed wrong signs. The zero cases have a population identified set touching $q^*=.3$; *not* a solver failure. **Done.** |
| 6 | False-plug-in stress test misleadingly correct in one world | Explains that the $q=.4$ correct sign follows from the direction of misspecification, not calibration dispensability. Retains original $q=.2$ 1000/1000 false signatures with miscalibration. | Original experiment CSV re-run **byte-identical**; all original summary numeric fields identical after stripping newly added `model_conflicts` field. **Done.** |
| 7 | Dynamic formula, joint nuisance, calibration and LP need proof | Added explicit sensor rates, nuisance/model distinction, exact Fourier–Motzkin projection, feasible witness interval and proof in Appendix A; explains augmentation of Theorem 8's linear parameter with $(1,q,h)$. | `upgrade_checks.py`: 1000 randomly generated projected identified sets compared with **separate SciPy two-variable LP**; all agree; witness values satisfy feasible joint constraints. **Done for the specified linked-offset model, not arbitrary nonlinear calibration.** |
| 8 | Algorithm needs ModelConflict, not crash on a failure-event empty set | All three runners now treat `status=2` as ModelConflict/abstention, exclude it from errors/signatures, charge budget-censored cost, record conflicts; never sign from empty interval. | Original rerun identical records; 0 conflicts in the *reported* cells. Injected inconsistent LP case remains in `theory_checks.py`. **Implemented, not a guarantee conflicts never occur.** |
| 9 | Anytime validity and error-rate interpretation | Uses original simple simultaneous Hoeffding family with M=2 for composite, M=1 for single proxy; added full $(q,h)$ mean-coverage diagnostic, not only $q$ projection. Keeps error denominator across all runs. | `results/dynamic_summary.json`: 0 observed full-model confidence failures in reported 16 synthetic cells; original and hard/boundary coverage audits pass. 0/240 Wilson 95% upper bound ≈0.01575, 0/500 ≈0.00762. **Observed only; theoretical conditional bound remains Theorem 8.** |
| 10 | “Fact sampling infinite cost” confusion | Retains formal observational-equivalence theorem and $2\delta$ signing ceiling; distinguishes impossible joint correctness+abstention requirement from actual infinite money spent. | Algebraic/proof inspection and original 128/128 deterministic factual transcript checks in `theory_checks.py`. **Original theorem preserved; general resettable RL not covered.** |
| 11 | Tiny decimal c_A makes example look tuned | Main result now gives an **open** valid charge interval; exact $c_A=.57487825$ and numeric witness moved to appendix, with original code checks preserved. | `theory_checks.py` and `legacy_two_stage_checks.py` both pass; original $\lambda=0$ baseline intact. **Done.** |
| 12 | Code provenance/GitHub | Removed fake clickable `github.com/USERNAME/REPOSITORY` URL. Gives explicit GitHub URL and commit SHA *not-yet-created* slots; bundles all code/results, independently compile-tested minimal `arxiv_source/`. | PDF grep and clean source compile, ZIP entries/CRC test, 9 figures all valid. **Archive done; public repository, commit and submission NOT done.** |
| 13 | Completed versus unexecuted experiment inventory | First paragraph of §6 states exact original 12,000, new 3,840, new 5,000, analytic-only objects and named missing work. Calls new studies *post-review exploratory*, not preregistered. | CSV row counts and script output reconciled; 20,840 records. **Done.** |
| 14 | Actual source/figures and submission quality | Added 4 post-review plots, report on actual adaptive algorithm, restricted-cost/error tables, better limits and related work; final PDF rendered and independently compared to text/table output. | `latexmk`, PDF page count 16, text inspection, image-contact sheet, clean compile, no unresolved references. **Done for local TeX build; journal editorial review not done.** |
| 15 | Literature originality boundary | Retains documented comparison to Han (2024), Ben-Michael et al. (2024), Koch--Imai, Oberst--Sontag, Buesing, Li et al. (2026), and rejects first-ever LP/partial-identification claims. | Cross-checked key original publication/arXiv listings. **No exhaustive full-text plagiarism/priority certification; independent specialist check remains mandatory.** |
| 16 | Missing fixed validation fees, long-horizon learned RL, real sensors | Explicit *Not executed* list in §6 and Discussion. No invented calibration cohort, costs or real-world samples. | Source/data inventory contains no such datasets. **Not done; intentionally disclosed.** |

## Commands used for verification

```bash
python theory_checks.py                 # PASS six original checks and 128/128 factual policies
python legacy_two_stage_checks.py       # PASS original 2-stage law/gap/LP/proxy checks
python run_experiments.py               # original CSV byte-identical to supplied predecessor
python dynamic_acquisition.py           # 3840 new records, actual data-dependent choices
python hard_cases.py                    # 5000 new records, near-threshold and boundary
python upgrade_checks.py               # PASS A--G independent model/LP/raw-data/figure audits
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex  # earlier upgrade: 16 pages; arXiv preflight: 17 pages
```

All results are inside `results/` with their source configurations/seeds; all nine plotted figures are inside `figures/`. Source-code-generated evidence and theorem proofs are **different** forms of verification. The scripts' independent constraints and enumerations check implementation identities, not priority relative to all existing published/unpublished research. No unobserved pair of potential outcomes is passed to any certification rule.

## Open release checklist

1. Commission an independent mathematical proof audit and full-text originality/overlap examination, especially the general irrevocable-branch theorem and distinctions from Han/Ben-Michael/Oberst--Sontag.
2. If an application is proposed, actually validate the cross-world proxy and linked-sensor calibration/transport, or report only explicit sensitivity sets and abstention. Do not repurpose simulator's hidden labels as real evidence.
3. Perform genuinely new fixed-fee, delayed-outcome, resettable/branch-switching and longer-horizon experiments if making claims about those settings; do not claim them in this version.
4. For public reproducibility, submit the packaged `arxiv_source/anc/` file with the TeX source; a separate GitHub repository and commit are optional. No public URL or arXiv posting is claimed before upload.
5. Confirm arXiv/venue-specific licenses, formats, metadata and any eligibility/endorsement requirements before submission; obtain independent-machine replication and editorial review.


## Final editorial freeze: recommendation-by-recommendation verification (18 September 2026)

This section documents the *final* changes to the preceding 16-page manuscript. It does not retroactively turn exploratory tests into preregistration or self-audit into independent peer review. Existing experimental scripts, raw data and generated plots were not modified to manufacture new results.

| Reviewer/author recommendation | Exact final action | Verification or remaining condition |
|---|---|---|
| §6.1 incorrectly says the Witness heuristic is unimplemented | The static Targeted/Uniform allocation is now distinguished from the **implemented two-parameter linked-offset Witness** tested in §6.2; the general finite-SCM procurement step remains a template. | Check `paper.tex` and `arxiv_source/paper.tex` for the corrected §6.1 sentence and `unimplemented general composite-world witness heuristic` absence. |
| Unclosed quotation mark in §5 transition | Replaced the dangling quote with two complete sentences distinguishing static Targeted from implemented Witness. | Search both TeX sources and extracted compiled PDF for the old phrase. |
| Consistent algorithm scope | Algorithm 1 caption and selection step explicitly label the general certification protocol and limit the executable witness rule to the linked-offset `(q,h)` submodel. Introduction, abstract, §5.1 and Discussion retain this restricted claim. | Inspect both TeX sources and executable `dynamic_acquisition.py`; the general finite-SCM optimizer is **not** claimed as implemented. |
| Exploratory results must stay exploratory | §6 retains the original 12,000-run study and separately marks the added 3,840 composite and 5,000 hard/boundary repetitions as post-review, not prospectively preregistered. No fabricated significance or universal cost gain. | Existing 20,840 CSV rows and 9 plots kept byte-identical to original ZIP; `upgrade_checks.py` independently recomputes stated costs/SE. |
| GitHub placeholder and public replication | Removed non-live URL and fake commit fields from the PDF; now describes the companion local ZIP and states **no public repository, stable public link, or commit exists**. | Publication of a stable, versioned research archive is still for the author to do. GitHub specifically is **not** a universal arXiv requirement. No URL or SHA was invented. |
| Optional false linked-offset experiment | **Not performed**, to avoid inserting an unverified eleventh-hour experiment. §6 and Discussion explicitly distinguish the existing original E6 single-proxy misspecification from this untested composite-model failure mode. | Listed under *Not executed*; no result or theorem about linked-offset misspecification is claimed. |
| Manuscript/source parity and packaging | Synced `paper.tex` with `arxiv_source/paper.tex`; regenerated the requested PDF from the former and the manifest for the requested ZIP. | Clean LaTeX build, Python checks, CRC, output filenames, PDFs and raw-data-preservation results are recorded in the final verification log in `results/final_verification.log`. |

### Checks still outside the scope of this edit

A mathematically independent proof audit, exhaustive originality/full-text priority review, real calibration evidence, independently hosted public repository, independent-machine replication, and venue-specific acceptance remain **unverified**. The original experiments and all their reported estimates are unchanged; a style/consistency correction cannot validate untested science.

## 2026-09-18 arXiv preflight: document and source-only changes

This stage preserves original scientific conclusions, existing raw simulation files,
figures, and experimental scripts. The manuscript now explicitly gives the 16-cell
composite decomposition (four `(q,h)` settings × four rules), separates all four
per-cell seed rules, gives one actual verification command, and adds a claim/evidence
map and scoped notation table. The theorem-2 limitation is kept distinct from the
fixed-pair limitation of the anytime certificate. Formula numbers are cross-referenced
through LaTeX labels. No extra real experiments, public URL, DOI or Git commit is claimed.

The `arxiv_source/anc/` directory now includes an explicitly version-identified
research-data ZIP, made from unchanged original results/scripts together with this
revision's README, seed ledger and verification command. An arXiv TeX submission must
include the complete source tree and ancillary ZIP; that upload is not performed here.
Independent-machine replication and real proxy validation remain outstanding.

Preflight compilation is now 17 pages; the earlier 16-page notes above are historical. The ancillary SHA-256 in the PDF fixes the exact source-data revision, and its `DATA_MANIFEST.sha256` verifies the archived bytes. The full source ZIP must be redistributed together with the PDF; nothing has been uploaded to arXiv by this process.

## 2026-09-18 final PDF/source sync (editorial changes only)

- **Source parity:** Replaced both the companion root `paper.tex` and
  `arxiv_source/paper.tex` with the same TeX from the finalized PDF's arXiv
  submission source. Their SHA-256 values must match.
- **Statistical notation:** §6.1 now describes the confidence radius using the
  *predeclared* number of feature streams, consistent with Theorem 8; no
  inference algorithm or data were changed.
- **Abstention symbol:** Theorem 10, its proof, the restricted two-world theorem,
  associated appendix discussion and notation table consistently use
  `\beta_{\\mathrm{abs}}`, distinct from proxy specificity `\beta`.
- **Layout and metadata:** Added the relevant LaTeX float control, resolved the
  interruption in the related-work paragraph/table, and set `pdfauthor`.
- **Immutable science:** Ancillary ZIP, its published SHA-256 digest, nine figure
  images, and all 20,840 original simulation records/scripts are unchanged.
  This synchronization is not independent proof review or a new experiment.
- **Verification:** The final package was hash-checked, the source recompiled
  from the extracted outer archive, and the resulting PDF's extracted text
  compared with the separately delivered 17-page manuscript. See checks in
  the assistant's delivery message. The outer `MANIFEST.sha256` and root `DATA_MANIFEST.sha256` were regenerated
  to reflect only updated files; the ancillary archive and its internal manifest stay unchanged.
