"""Independent, fail-fast analytic, exhaustive-kernel, LP, calibration, and bound checks."""
from itertools import product
from math import isclose, log
import numpy as np
from scipy.optimize import linprog
from model import (GAMMA,P0,P1,RHO,CA,C1,C2,R,B2RATE,SCENARIOS,mass,joint,
                   gap,scenario_gap,target,factorial_law,lp_bounds,proxy_mean,
                   q_interval_from_proxy,COEFFICIENT,QSTAR)

def close(x,y,tol=1e-10): assert isclose(x,y,abs_tol=tol,rel_tol=tol),(x,y)
qgrid=np.linspace(.2,.4,9)
for q in qgrid:
    weights=joint(q)
    close(sum(weights.values()),1)
    assert min(weights.values())>=-1e-12
    close(sum(i*p for (i,j),p in weights.items()),P0)
    close(sum(j*p for (i,j),p in weights.items()),P1)
    close(sum(mass(q,sc) for sc in SCENARIOS),1)
    oracle=sum(mass(q,sc)*scenario_gap(sc) for sc in SCENARIOS)
    close(oracle,gap(q))
    close(gap(q),COEFFICIENT*(q-QSTAR))
close(CA,.57487825);close(B2RATE,.28);close(gap(.2),-.02572125);close(gap(.4),.02572125)
close(gap(.2,0),-.31722875);close(gap(.4,0),-.31722875)
print('PASS 01: joint weights, normalized 16-scenario worlds, dynamic gap and lambda=0')
# Enumerate all deterministic policies: initial A, B1(S1), B2(S1,C2).
count=0
for a,b10,b11,b200,b201,b210,b211 in product((0,1),repeat=7):
    bb=lambda s,b10=b10,b11=b11: (b10,b11)[s]
    cc=lambda s,c,bs=(b200,b201,b210,b211):bs[2*s+c]
    x=factorial_law(.2,a,bb,cc)
    y=factorial_law(.4,a,bb,cc)
    assert x.keys()==y.keys()
    for k in x:close(x[k],y[k])
    count+=1
assert count==128
print('PASS 02: all 128 deterministic within-unit adaptive factual-policy laws match')
lo,hi=lp_bounds();close(lo,gap(.2));close(hi,gap(.4))
lo_relax,hi_relax=lp_bounds(allow_dependence=True)
assert lo_relax<=lo+1e-10 and hi_relax>=hi-1e-10
# Independent enumeration of 2x2 coupling vertices (not computed by the LP).
vertex_vals=[sum(mass(q,sc)*scenario_gap(sc) for sc in SCENARIOS) for q in (.2,.4)]
close(min(vertex_vals),lo);close(max(vertex_vals),hi)
print(f'PASS 03: LP = vertex enumeration [{lo:.8f},{hi:.8f}]; relaxed bounds [{lo_relax:.8f},{hi_relax:.8f}]')
# exact proxy moments from full (Y0,Y1,Z) enumeration, and calibration envelope.
for q in qgrid:
    for al,be in ((.9,.9),(.65,.85),(.5,.5)):
        m=sum(p*(al if y0 else 1-be) for (y0,y1),p in joint(q).items() if y1==0)
        close(m,proxy_mean(q,al,be))
        interval=q_interval_from_proxy(m,m,.8,.8,(al,al),(be,be))
        if al+be-1>0.001: assert interval and interval[0]-1e-9<=q<=interval[1]+1e-9
# For known calibration: inverse exact and point identified; for rectangles: interval contains truth.
for q in qgrid:
    m=proxy_mean(q,.9,.9)
    x=q_interval_from_proxy(m,m,.8,.8,(.9,.9),(.9,.9));assert x
    close(x[0],q);close(x[1],q)
    y=q_interval_from_proxy(m,m,.8,.8,(.85,.95),(.85,.95));assert y and y[0]-1e-9<=q<=y[1]+1e-9
assert q_interval_from_proxy(.05,.05,.8,.8,(.9,.9),(.9,.9)) is None
print('PASS 04: proxy mixture algebra, robust-calibration LP and conflict detection')
# Finite-budget lower bound vs fixed-channel upper bound, no claim of general minimax.
delta=.05;eta=.1;eps=.1;s=.8;c=2
kl=lambda p,q:p*log(p/q)+(1-p)*log((1-p)/(1-q))
n=int(np.ceil(log(1/delta)/(2*s*s*eta*eta)))
assert np.exp(-2*n*s*s*eta*eta)<=delta
mplus=proxy_mean(.4);mminus=proxy_mean(.2)
assert min(mplus,mminus)>=eps and max(mplus,mminus)<=1-eps
lower=kl(1-delta,delta)/(max(kl(mplus,mminus),kl(mminus,mplus))/c)
assert c*n>=lower-1e-9
beta=.1
budget_lower=kl(1-beta-delta,delta)/max(kl(mplus,mminus),kl(mminus,mplus))*c
assert budget_lower>0 and beta+2*delta<1
print(f'PASS 05: fixed-budget/sign-abstention KL bound positive; two-world fixed-channel n={n}')
print('PASS 06: all independent checks completed')
