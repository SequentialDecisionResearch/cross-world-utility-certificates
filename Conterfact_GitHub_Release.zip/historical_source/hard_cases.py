"""Hard-margin and calibration-boundary synthetic stress tests; no real data."""
import json,csv,argparse
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import run_experiments as original
from dynamic_acquisition import radius as cs_radius
from model import proxy_mean, QSTAR
ROOT=Path(__file__).resolve().parent

def margin_cell(q,R,budget,batch,seed):
    rng=np.random.default_rng(seed)
    counts=np.zeros(R,dtype=int);status=np.zeros(R,dtype=int);spent=np.zeros(R,dtype=float)
    sums=np.zeros(R,dtype=int)
    costs=np.full(R,np.nan);miss=np.zeros(R,dtype=bool)
    for _ in range(budget//(2*batch)):
        idx=np.flatnonzero(status==0)
        if not len(idx):break
        p=proxy_mean(q,.9,.9)
        successes=rng.binomial(batch,p,size=len(idx))
        # Running sums are stored separately; no access to the latent oracle.
        sums[idx]+=successes
        counts[idx]+=batch;spent[idx]+=2*batch
        mean=sums[idx]/counts[idx]
        r=cs_radius(counts[idx,None],m=1).ravel()
        qlo=np.maximum(.2,(mean-r-.08)/.8)
        qhi=np.minimum(.4,(mean+r-.08)/.8)
        miss[idx]|=(qlo>q+1e-10)|(qhi<q-1e-10)
        conflict=qlo>qhi+1e-9
        status[idx[conflict]]=2
        idx=idx[~conflict];qlo=qlo[~conflict];qhi=qhi[~conflict]
        pos=idx[qlo>QSTAR+1e-10];neg=idx[qhi<QSTAR-1e-10]
        status[pos]=1; status[neg]=-1
        successes_idx=np.concatenate([pos,neg])
        costs[successes_idx]=spent[successes_idx]
    signed=np.isfinite(costs)
    return {'q':q,'margin':abs(q-QSTAR),'R':R,'budget':budget,'signed':int(signed.sum()),
      'wrong':int(np.sum((np.abs(status)==1)&(status!=np.sign(q-QSTAR)))),
      'model_conflicts':int(np.sum(status==2)),
      'coverage_failures':int(miss.sum()),'restricted_cost':float(np.where(signed,costs,budget).mean()),
      'restricted_cost_se':float(np.where(signed,costs,budget).std(ddof=1)/np.sqrt(R)),
      'costs':costs,'spent':spent,'misses':miss}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    R=35 if args.quick else 500
    out=ROOT/('results_quick' if args.quick else 'results');figs=ROOT/('figures_quick' if args.quick else 'figures')
    out.mkdir(exist_ok=True);figs.mkdir(exist_ok=True)
    budget=180000
    hard={}; boundary={}; rows=[]
    for j,q in enumerate((.2,.25,.28,.32,.35,.4)):
        x=margin_cell(q,R,budget,100,280000+j*101)
        hard[str(q)]=x
        print('margin',q,'signed',x['signed'],'restricted',round(x['restricted_cost']),flush=True)
        for i in range(R):rows.append(['margin',q,'',i,int(np.isfinite(x['costs'][i])),float(x['costs'][i]) if np.isfinite(x['costs'][i]) else '',float(x['costs'][i]) if np.isfinite(x['costs'][i]) else budget,int(x['misses'][i])])
    original.BUDGET=12000
    for j,(q,aa,be) in enumerate(((.2,.85,.95),(.2,.95,.85),(.4,.85,.95),(.4,.95,.85))):
        x=original.experiment_cell(q,R,'targeted',true_cal={'strong':(aa,be)},
                                   assumed_cal={'strong':(.9,.9)},robust=True,strong_only=True,
                                   seed=290000+j*109)
        k=f'q{q:.1f}_alpha{aa:.2f}_beta{be:.2f}'
        boundary[k]=x
        print('boundary',k,'signed',x['certified'],'wrong',x['wrong'],flush=True)
        for i in range(R):rows.append(['boundary',q,f'{aa}:{be}',i,int(np.isfinite(x['costs'][i])),float(x['costs'][i]) if np.isfinite(x['costs'][i]) else '',float(x['costs'][i]) if np.isfinite(x['costs'][i]) else 12000,int(x['ever_missed_true_q'][i])])
    with open(out/'hard_replicates.csv','w',newline='') as f:
        w=csv.writer(f);w.writerow(['study','q','calibration','replicate','signed','certification_cost','censored_cost','ever_missed_truth']);w.writerows(rows)
    def clean(r):return {k:v for k,v in r.items() if k not in ('costs','spent','misses','statuses','ever_missed_true_q')}
    summ={'R':R,'hard_budget':budget,'hard_batch':100,'hard':{k:clean(v) for k,v in hard.items()},
          'boundary_budget':12000,'boundary':{k:clean(v) for k,v in boundary.items()}}
    with open(out/'hard_summary.json','w') as f:json.dump(summ,f,indent=2)
    fig,ax=plt.subplots(figsize=(7.3,3.5))
    vals=[hard[str(q)]['restricted_cost'] for q in (.2,.25,.28,.32,.35,.4)]
    ax.bar(range(6),vals)
    ax.set(xticks=range(6),xticklabels=['.20','.25','.28','.32','.35','.40'],
           xlabel='True coupling q (threshold .30)',ylabel='Restricted mean cost (cap 180,000)',
           title='Harder decision margins under known exact calibration')
    fig.tight_layout();fig.savefig(figs/'figure_margin.png',dpi=195);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.4,3.2))
    labels=list(boundary)
    ax.bar(range(4),[boundary[k]['cert_rate'] for k in labels])
    ax.set(xticks=range(4),xticklabels=[k.replace('_','\n') for k in labels],
           ylabel='Signed / all repetitions',ylim=(0,1),
           title='True calibration on justified sensitivity-rectangle boundary')
    fig.tight_layout();fig.savefig(figs/'figure_calibration_edge.png',dpi=195);plt.close(fig)
    print('WROTE',len(rows),'hard and boundary repetitions')
if __name__=='__main__':main()
