"""Finite, irrevocable-branch cross-world SCM; synthetic use only.

No paired Y0,Y1 is exposed by factual_observation() or proxy_observation().
Paired latent labels are used internally for generation and in validation tests,
but factual_observation() and proxy_observation() return only single-world data.
"""
from itertools import product
import numpy as np
from scipy.optimize import linprog
GAMMA=.95
P0=.4; P1=.2; RHO=.6
C1=.05; C2=.04
LAMBDA=1.
QSTAR=.3
R=RHO/2
B2RATE=.5*(P1*(1-RHO)+(1-P1)*RHO)
F_BASE=GAMMA**3*(P0-R*P1)-GAMMA*C1/2-GAMMA**2*C2*B2RATE
COEFFICIENT=GAMMA**3*R
CA=F_BASE+GAMMA**3*(1-R)*P0+COEFFICIENT*QSTAR
SCENARIOS=list(product((0,1),repeat=4)) # (V1,V2,Y0,Y1)

def joint(q):
    if not .2-1e-12<=q<=.4+1e-12: raise ValueError('q outside Frechet range')
    return {(0,0): .8-q,(1,0):q,(0,1):q-.2,(1,1):.4-q}

def mass(q,sc):
    v1,v2,y0,y1=sc
    return .5*(RHO if v2 else 1-RHO)*joint(q)[(y0,y1)]

def rollout(sc,a,b1_of_s,b2_of_s_c):
    v1,v2,y0,y1=sc
    ya=(y0,y1)[a]
    s=a^v1
    b1=b1_of_s(s)
    c=ya^v2
    b2=b2_of_s_c(s,c)
    harm=ya*(1-b1)*(1-b2)
    rew=-CA*a-GAMMA*C1*b1-GAMMA**2*C2*b2-GAMMA**3*harm
    return (s,b1,c,b2,harm,round(rew,12))

def target(sc,arm):
    if arm==0: return rollout(sc,0,lambda s:0,lambda s,c:0)
    return rollout(sc,1,lambda s:s,lambda s,c:(1-s)*c)

def scenario_gap(sc,lam=LAMBDA):
    x0=target(sc,0);x1=target(sc,1)
    return x1[-1]-x0[-1]+lam*GAMMA**3*int(x0[4]==1 and x1[4]==0)

def gap(q,lam=LAMBDA):
    return F_BASE-CA+lam*GAMMA**3*((1-R)*P0+R*q)

def factual_observation(q,a,b1_of_s,b2_of_s_c,rng):
    if not a in (0,1):raise ValueError(a)
    y0y1=tuple(joint(q))
    y0,y1=y0y1[rng.choice(len(y0y1),p=list(joint(q).values()))]
    sc=(int(rng.integers(2)),int(rng.random()<RHO),y0,y1)
    return rollout(sc,a,b1_of_s,b2_of_s_c)

def proxy_mean(q,alpha=.9,beta=.9,v=.8):
    return alpha*q+(1-beta)*(v-q)

def proxy_observation(q,alpha,beta,rng):
    # The logger sees Y1 and Z, NEVER the paired Y0.
    y0y1=tuple(joint(q))
    y0,y1=y0y1[rng.choice(len(y0y1),p=list(joint(q).values()))]
    z=int(rng.random() < (alpha if y0==1 else 1-beta)) if y1==0 else int(rng.integers(2))
    return y1,z

def factorial_law(q,a,b1_of_s,b2_of_s_c):
    out={}
    for sc in SCENARIOS:
        w=mass(q,sc)
        obs=rollout(sc,a,b1_of_s,b2_of_s_c)
        out[obs]=out.get(obs,0)+w
    return {k:v for k,v in out.items() if v>1e-12}

def lp_bounds(allow_dependence=False):
    # All equations are on THE SAME distribution of complete mechanisms.
    d=np.array([scenario_gap(sc) for sc in SCENARIOS])
    a=[[1.]*len(SCENARIOS),[float(sc[2]) for sc in SCENARIOS],[float(sc[3]) for sc in SCENARIOS],
       [float(sc[0]) for sc in SCENARIOS],[float(sc[1]) for sc in SCENARIOS]]
    b=[1,P0,P1,.5,RHO]
    if not allow_dependence:
        # P((V1,V2)=(v,w), (Y0,Y1)=(i,j)) = P(V1=v,V2=w)*P((Y0,Y1)=(i,j)).
        for (v,w) in product((0,1),repeat=2):
            pv=.5*(RHO if w else 1-RHO)
            for (i,j) in product((0,1),repeat=2):
                a.append([float(sc==(v,w,i,j))-pv*float(sc[2:]==(i,j)) for sc in SCENARIOS]);b.append(0)
    low=linprog(d,A_eq=a,b_eq=b,bounds=(0,None),method='highs')
    high=linprog(-d,A_eq=a,b_eq=b,bounds=(0,None),method='highs')
    if not(low.success and high.success):raise RuntimeError('LP failed')
    return float(low.fun),float(-high.fun)

def q_interval_from_proxy(m_lo,m_hi,v_lo,v_hi,alpha_interval,beta_interval):
    """Sharp projection for rectangular calibration intervals, for fixed binary submodel.

    Variables x=(q,v,m); alpha and beta ranges give linear envelope inequalities.
    q in [max(0,v-(1-p0)),min(p0,v)] and v=1-p1=.8 for the analytic design.
    Returns bounds by LP, or None for model conflict.
    """
    al,au=alpha_interval;bl,bu=beta_interval
    # mmin=(al+bu-1)q + (1-bu)v; mmax=(au+bl-1)q + (1-bl)v
    aub=[[al+bu-1,1-bu,-1],[-(au+bl-1),-(1-bl),1],
         [1,-1,0],[-1,1,0],[1,0,0]]
    # q >= v-(1-p0): -q+v <= 1-p0; and q <= p0.
    bub=[0,0,0,1-P0,P0]
    bounds=[(0,1),(v_lo,v_hi),(m_lo,m_hi)]
    lo=linprog([1,0,0],A_ub=aub,b_ub=bub,bounds=bounds,method='highs')
    hi=linprog([-1,0,0],A_ub=aub,b_ub=bub,bounds=bounds,method='highs')
    return (float(lo.fun),float(-hi.fun)) if lo.success and hi.success else None
