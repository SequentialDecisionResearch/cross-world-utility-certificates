"""Fail-fast independent verification of all *reported* post-review outputs.

Only synthetic numerical and source-integrity checks, not independent peer review.
"""
from pathlib import Path
from itertools import product
import csv,json,math
import numpy as np
from scipy.optimize import linprog
from model import joint,proxy_mean
from dynamic_acquisition import (BASE,S,H,QSTAR,QLO,QHI,PRICES,bounds,lp_reference,
                                 witness_h,select_channels)
ROOT=Path(__file__).resolve().parent
R=ROOT/'results'

def near(a,b,tol=1e-6):
    assert np.isclose(a,b,rtol=0,atol=tol),(a,b)

# New sensor kernel constructed from conditional rates, not the closed-form mean.
for q,h in product(np.linspace(.2,.4,13),np.linspace(-H,H,11)):
    for e in (-1,1):
        al=.9+e*h; false_pos=.1+e*h
        assert 0<=al<=1 and 0<=false_pos<=1
        m=sum(p*(al if y0 else false_pos) for (y0,y1),p in joint(q).items() if y1==0)
        near(m,BASE+S*(q+e*h),2e-15)
print('PASS A: 286 independently enumerated synthetic conditional sensor means')

# Exact Fourier--Motzkin vs independent 2-dimensional LP for randomized sample histories.
rng=np.random.default_rng(428)
for j in range(1000):
    q,h=.28,.05
    n1,n2=rng.integers(0,30000,size=2)
    counts=np.array([[n1,n2]])
    sums=np.array([[rng.binomial(n1,BASE+S*(q+h)),rng.binomial(n2,BASE+S*(q-h))]])
    lo,hi,params=bounds(counts,sums)
    if lo[0]<=hi[0]+1e-9:
        lp_reference((n1,n2,sums[0,0],sums[0,1]))
        h_l=witness_h(lo,*params);h_u=witness_h(hi,*params)
        assert abs(h_l[0])<=H+1e-10 and abs(h_u[0])<=H+1e-10
    else:
        # Infeasible confidence set on a rare empirical failure event: no certificate.
        a,b,c,d=[x[0] for x in params]
        mats=[];vec=[]
        for v,low,up in (([1,1],a,b),([1,-1],c,d)):
            if np.isfinite(up):mats.append(v);vec.append(up)
            if np.isfinite(low):mats.append([-x for x in v]);vec.append(-low)
        z=linprog([1,0],A_ub=mats if mats else None,b_ub=vec if mats else None,
                  bounds=[(QLO,QHI),(-H,H)],method='highs')
        assert not z.success
print('PASS B: 1000 randomized projected sets = independent LP; witness points feasible')

# Actual policy step must be data-dependent and honor prior-only predictability.
rows=np.array([[2500,500],[100,20000],[5000,5000]],int)
sums=np.array([[800,125],[27,7000],[1600,1190]],int)
lo,hi,params=bounds(rows,sums)
assert np.all(lo<=hi)
choices=select_channels('witness',0,np.array([0,1,2]),rows,lo,hi,params)
assert choices.shape==(3,) and set(choices).issubset({0,1})
assert select_channels('uniform',0,np.array([0,1,2]),rows,lo,hi,params).tolist()==[0,0,0]
print('PASS C: witness choice uses empirical confidence endpoints and static comparator remains static')

# Original archive vs rerun: code change to conflict handling must not change the 12k outcomes.
old=json.loads((ROOT/'baseline_reference'/'summary.json').read_text())
new=json.loads((R/'summary.json').read_text())
for row in new['cells'].values():assert row['model_conflicts']==0;row.pop('model_conflicts')
assert new==old
assert (R/'replicates.csv').read_bytes()==(ROOT/'baseline_reference'/'replicates.csv').read_bytes()
print('PASS D: old 12,000-repetition CSV byte-identical; summary identical after new conflict field')

# New dynamic runs: compare every cell's reported rate/cost against *raw CSV*, including abstentions.
d=json.loads((R/'dynamic_summary.json').read_text())
with open(R/'dynamic_replicates.csv',newline='') as f: drows=list(csv.DictReader(f))
assert len(drows)==16*240
for key,info in d['cells'].items():
    sample=[x for x in drows if x['condition']==key]
    assert len(sample)==240
    cert=[x for x in sample if x['certificate_cost']]
    assert len(cert)==info['signed']
    assert sum(int(x['status']) in (-1,1) and int(x['status'])!=np.sign(info['q']-QSTAR) for x in cert)==info['wrong']
    near(np.mean([float(x['censored_cost']) for x in sample]),info['restricted_cost'])
    assert sum(int(x['ever_missed_full_model']) for x in sample)==info['full_model_coverage_failures']
    assert sum(int(x['ever_missed_q']) for x in sample)==info['coverage_failures']
    assert all(float(x['spent'])<=info['budget']+1e-8 for x in sample)
    assert all(int(x['n_plus'])*PRICES[0]+int(x['n_minus'])*PRICES[1]==float(x['spent']) for x in sample)
print('PASS E: 3840 dynamic replication rows, q/h coverage, signature errors, prices, censoring reconciled')

# Hard margins/boundary, including the failures that cost the full budget.
h=json.loads((R/'hard_summary.json').read_text())
with open(R/'hard_replicates.csv',newline='') as f: hrows=list(csv.DictReader(f))
assert len(hrows)==5000
for name,group in (('margin',h['hard']),('boundary',h['boundary'])):
    for key,info in group.items():
        if name=='margin':
            selection=[x for x in hrows if x['study']=='margin' and float(x['q'])==float(key)]
        else:
            qq=float(key.split('_')[0][1:]);aa=float(key.split('alpha')[1].split('_')[0]);bb=float(key.split('beta')[1])
            selection=[x for x in hrows if x['study']=='boundary' and float(x['q'])==qq and x['calibration']==f'{aa}:{bb}']
        assert len(selection)==500,(name,key,len(selection))
        signed=info['signed'] if name=='margin' else info['certified']
        assert sum(int(x['signed']) for x in selection)==signed
        assert sum(int(x['ever_missed_truth']) for x in selection)==(info['coverage_failures'] if name=='margin' else info['ever_missed_true_q_count'])
        if name=='margin':near(np.mean([float(x['censored_cost']) for x in selection]),info['restricted_cost'])
        assert info['wrong']==0
print('PASS F: 5000 hard/boundary rows reconcile with article counts and censoring')

# Recompute approximate independent-replicate SE for the two highlighted differences.
for q,hval in ((.28,.05),(.32,-.05)):
    a=d['cells'][f'q{q:.2f}_h{hval:+.2f}_uniform'];b=d['cells'][f'q{q:.2f}_h{hval:+.2f}_witness']
    diff=a['restricted_cost']-b['restricted_cost']
    se=math.hypot(a['restricted_cost_se'],b['restricted_cost_se'])
    print(f'CHECK uncertainty q={q}: uniform-minus-witness={diff:.1f}, MC SE={se:.1f}, exploratory 95% normal interval=[{diff-1.96*se:.1f},{diff+1.96*se:.1f}]')

from PIL import Image
for name in ['figure1.png','figure2.png','figure3.png','figure4.png','figure5.png','figure_dynamic.png',
             'figure_dynamic_cost.png','figure_margin.png','figure_calibration_edge.png']:
    im=Image.open(ROOT/'figures'/name);im.verify()
assert len(list((ROOT/'figures').glob('*.png')))==9
print('PASS G: nine valid generated figures; all upgraded checks completed')
