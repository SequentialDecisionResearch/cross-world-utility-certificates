"""Independent structural and analytic checks. This is not a simulation study."""
from itertools import product
from math import isclose, log, pi, sqrt
import numpy as np
from scipy.optimize import linprog
q_values = [0.2, 0.25, 0.3, 0.35, 0.4]
weights = lambda q: {(0,0): 0.8-q, (1,0):q, (0,1):q-0.2, (1,1):0.4-q}
assert all(isclose(sum(weights(q).values()),1) and min(weights(q).values()) >= -1e-12 for q in q_values)
assert all(isclose(sum(y0*w for (y0,y1),w in weights(q).items()),.4) for q in q_values)
assert all(isclose(sum(y1*w for (y0,y1),w in weights(q).items()),.2) for q in q_values)
gamma = .95
ca,cb=.5575,.05

def law(q, a, b_of_s):
    observed={}
    expectation_gap=0.0
    for v,(y0,y1) in product([0,1],weights(q)):
        w=.5*weights(q)[(y0,y1)]
        s=a^v; b=b_of_s(s); y=(y0,y1)[a]*(1-b)
        key=(s,b,y,round(-gamma**2*y-ca*a-gamma*cb*b,10))
        observed[key]=observed.get(key,0)+w
    return observed
for a in [0,1]:
 for b0,b1 in product([0,1],repeat=2):
  p=law(.2,a,lambda s,b0=b0,b1=b1:b0 if s==0 else b1)
  p2=law(.4,a,lambda s,b0=b0,b1=b1:b0 if s==0 else b1)
  assert p.keys()==p2.keys() and all(isclose(p[k],p2[k],abs_tol=1e-12) for k in p)

def gap_by_enumeration(q):
    value=0
    for v in [0,1]:
     for (y0,y1),w0 in weights(q).items():
      s0=0^v; b0=0; harm0=y0
      s1=1^v; b1=s1; harm1=y1*(1-b1)
      factual = gamma**2*(harm0-harm1)-ca-gamma*cb*b1
      bonus=gamma**2*(harm0==1 and harm1==0)
      value += .5*w0*(factual+bonus)
    return value
for q in q_values:
    assert isclose(gap_by_enumeration(q),-.13+.45125*q,abs_tol=1e-12)
# The saturated scenario simplex has eight shared types (V,Y0,Y1).
scenarios=list(product([0,1], repeat=3))
d=np.array([gamma**2*(y0-y1*(1-(1^v)))-ca-gamma*cb*(1^v)+gamma**2*(y0==1 and y1*(1-(1^v))==0) for v,y0,y1 in scenarios])
A=np.array([[1.]*8,[float(y0) for v,y0,y1 in scenarios],[float(y1) for v,y0,y1 in scenarios]])
low=linprog(d,A_eq=A,b_eq=[1,.4,.2],bounds=[(0,None)]*8,method='highs')
high=linprog(-d,A_eq=A,b_eq=[1,.4,.2],bounds=[(0,None)]*8,method='highs')
assert low.success and high.success
# Unrestricted V-dependence may change sharp bounds; independence of V and (Y0,Y1)
# must be imposed as linear constraints, not silently omitted.
# The independence constraints above depend on the unknown joint cell probabilities;
# use matching differences P(V=0,type)=P(V=1,type).
A_ind=np.vstack([A,np.array([[float((1 if v==0 else -1) if (y0,y1)==(a,b) else 0) for v,y0,y1 in scenarios] for a,b in product([0,1],repeat=2)])])
lo=linprog(d,A_eq=A_ind,b_eq=[1,.4,.2,0,0,0,0],bounds=[(0,None)]*8,method='highs')
hi=linprog(-d,A_eq=A_ind,b_eq=[1,.4,.2,0,0,0,0],bounds=[(0,None)]*8,method='highs')
assert lo.success and hi.success
assert isclose(lo.fun,-.03975,abs_tol=1e-10) and isclose(-hi.fun,.0505,abs_tol=1e-10), (lo.fun,-hi.fun)
for q in [.2,.35,.4]:
    m=.08+.8*q
    assert isclose((m-.08)/.8,q)
eta=.35-.13/.45125
n=int(2*log(2/.05)/(.8**2*eta**2))+1
assert n>2*log(2/.05)/(.8**2*eta**2)
print('PASS: all eight within-unit action kernels agree at the two endpoints')
print('PASS: all five two-stage gap values equal the closed-form expression')
print(f'PASS: shared finite-SCM LP endpoints are {lo.fun:.8f} and {-hi.fun:.8f}')
print('PASS: calibrated proxy algebra and fixed-sample sufficient-size inequality')
print('INFO: q*=%.9f; idealized sufficient n=%d; feasible q range=[.2,.4]'%(.13/.45125,n))
