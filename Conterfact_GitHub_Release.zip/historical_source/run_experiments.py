"""Synthetic, fully reproducible audit experiments E1--E6.

All outcomes are generated from the declared SCM. No external/real data and no
same-unit paired labels reach the learner. Oracle labels are for scoring/tests only.
Use --quick for the CI smoke run; default is 1000 independent replicates per cell.
"""
import argparse, json, csv, math, os
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import joint,gap,proxy_mean,lp_bounds,CA,COEFFICIENT,QSTAR
ROOT=Path(__file__).resolve().parent
SEED=260917
DELTA=.05
BUDGET=12000
BATCH=25
QMIN,QMAX=.2,.4
# Eligible binary proxy menus have externally stipulated known calibration.
CHANNELS={'strong':{'alpha':.9,'beta':.9,'cost':2},'weak':{'alpha':.725,'beta':.725,'cost':1}}

def radius(n,M):
    return np.sqrt(np.log(M*np.pi**2*n**2/(3*DELTA))/(2*n))

def wilson(k,n):
    if n==0:return (0.,1.)
    z=1.959963984540054;p=k/n
    denom=1+z*z/n
    mid=(p+z*z/(2*n))/denom
    hw=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/denom
    return [float(max(0,mid-hw)),float(min(1,mid+hw))]

def experiment_cell(q,R,allocation='targeted',true_cal=None,assumed_cal=None,
                    robust=False,strong_only=False,seed=0):
    rng=np.random.default_rng(seed)
    names=['strong'] if strong_only else list(CHANNELS)
    tcal=true_cal or {k:(CHANNELS[k]['alpha'],CHANNELS[k]['beta']) for k in names}
    acal=assumed_cal or {k:(CHANNELS[k]['alpha'],CHANNELS[k]['beta']) for k in names}
    counts={k:np.zeros(R,dtype=int) for k in names}
    sums={k:np.zeros(R,dtype=int) for k in names}
    spent=np.zeros(R,dtype=int)
    status=np.zeros(R,dtype=int) # +1/-1 signed; 0 unresolved; 2 ModelConflict
    cert_cost=np.full(R,np.nan)
    ever_missed_true_q=np.zeros(R,dtype=bool)
    budget_steps=BUDGET//BATCH # each round costs at least BATCH
    l=np.full(R,QMIN);u=np.full(R,QMAX)
    for t in range(budget_steps):
        eligible=np.flatnonzero(status==0)
        if len(eligible)==0:break
        if allocation=='uniform' and not strong_only:
            e=names[t%len(names)]
        else:
            e='strong'
        unit_price=CHANNELS[e]['cost']
        eligible=eligible[spent[eligible]+BATCH*unit_price<=BUDGET]
        if len(eligible)==0:break
        al,be=tcal[e]
        p=proxy_mean(q,al,be)
        sums[e][eligible]+=rng.binomial(BATCH,p,size=len(eligible))
        counts[e][eligible]+=BATCH
        spent[eligible]+=BATCH*unit_price
        l[eligible]=QMIN;u[eligible]=QMAX
        for channel in names:
            inds=eligible[counts[channel][eligible]>0]
            if not len(inds):continue
            nn=counts[channel][inds];hat=sums[channel][inds]/nn
            rr=radius(nn,len(names))
            ml=np.maximum(0,hat-rr);mu=np.minimum(1,hat+rr)
            aa,bb=acal[channel]
            v=.8
            if robust and channel=='strong':
                # Known rectangular calibration: alpha,beta each in [0.85,0.95].
                alow,aup=.85,.95;blow,bup=.85,.95
            else:
                alow=aup=aa;blow=bup=bb
            sl=alow+bup-1;su=aup+blow-1
            # m>=sl*q+(1-bup)*v and m<=su*q+(1-blow)*v
            # q lower from ml <= mmax, upper from mu >= mmin.
            if su>0:l[inds]=np.maximum(l[inds],(ml-(1-blow)*v)/su)
            if sl>0:u[inds]=np.minimum(u[inds],(mu-(1-bup)*v)/sl)
        ever_missed_true_q[eligible] |= (l[eligible]>q+1e-9) | (u[eligible]<q-1e-9)
        bad=l[eligible]>u[eligible]+1e-9
        if np.any(bad):status[eligible[bad]]=2  # abstain on the confidence failure event
        eligible=eligible[~bad]
        positives=eligible[l[eligible]>QSTAR+1e-10]
        negatives=eligible[u[eligible]<QSTAR-1e-10]
        status[positives]=1;status[negatives]=-1
        cert_cost[np.concatenate((positives,negatives))]=spent[np.concatenate((positives,negatives))]
    correct=1 if q>QSTAR else -1
    wrong=int(np.sum((np.abs(status)==1)&(status!=correct)))
    certified=int(np.sum(np.abs(status)==1))
    # Restricted mean of min(Tcert,B) is well defined, unlike success-only mean.
    restricted=float(np.mean(np.where(np.isnan(cert_cost),BUDGET,cert_cost)))
    return {'q':q,'allocation':allocation,'robust':robust,'R':R,
      'certified':certified,'wrong':wrong,'abstained':R-certified,
      'model_conflicts':int(np.sum(status==2)),
      'cert_rate':certified/R,'wrong_rate':wrong/R,'cert_rate_ci':wilson(certified,R),
      'wrong_rate_ci':wilson(wrong,R),'restricted_mean_cost':restricted,
      'mean_cost_success':float(np.nanmean(cert_cost)) if certified else None,
      'median_cost_success':float(np.nanmedian(cert_cost)) if certified else None,
      'costs':cert_cost,'statuses':status,'spent':spent,
      'ever_missed_true_q_count':int(np.sum(ever_missed_true_q)),
      'ever_missed_true_q':ever_missed_true_q,
      'restricted_mean_cost_se':float(np.std(np.where(np.isnan(cert_cost),BUDGET,cert_cost),ddof=1)/np.sqrt(R)),
      'final_mean_width':float(np.mean(np.maximum(0,u-l)))}

def factual_sim(q,R,n,rng):
    # Choose A uniformly; zero downstream investment makes both Ya observable by arm.
    # Across independent units we never reveal both Y0 and Y1.
    arms=rng.integers(0,2,size=(R,n))
    # Bernoulli factual potential outcome conditional on observed arm: entire factual law is invariant in q.
    ya=rng.random((R,n))<np.where(arms==0,.4,.2)
    ave0=np.sum((arms==0)*ya,axis=1)/np.maximum(1,np.sum(arms==0,axis=1))
    ave1=np.sum((arms==1)*ya,axis=1)/np.maximum(1,np.sum(arms==1,axis=1))
    return ave0,ave1

def strip_private(result):
    return {k:v for k,v in result.items() if k not in ('costs','statuses','spent','ever_missed_true_q')}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    R=80 if args.quick else 1000
    out=ROOT/('results_quick' if args.quick else 'results')
    fig=ROOT/('figures_quick' if args.quick else 'figures')
    out.mkdir(exist_ok=True);fig.mkdir(exist_ok=True)
    rng=np.random.default_rng(SEED)
    factual={}
    for q in (.2,.4):
        x,y=factual_sim(q,R,800,rng)
        factual[str(q)]={'p0':float(x.mean()),'p1':float(y.mean()),
            'p0_sd':float(x.std(ddof=1)),'p1_sd':float(y.std(ddof=1))}
    cells={}
    for q in (.2,.4):
      for allocation in ('targeted','uniform'):
        key=f'nominal_{q}_{allocation}'
        cells[key]=experiment_cell(q,R,allocation,seed=SEED+len(cells)*743)
      key=f'robust_{q}'
      cells[key]=experiment_cell(q,R,'targeted',robust=True,strong_only=True,seed=SEED+len(cells)*743)
      key=f'miscal_{q}'
      cells[key]=experiment_cell(q,R,'targeted',true_cal={'strong':(.5,.5)},
          assumed_cal={'strong':(.9,.9)},strong_only=True,seed=SEED+len(cells)*743)
      key=f'null_{q}'
      cells[key]=experiment_cell(q,R,'targeted',true_cal={'strong':(.5,.5)},
          assumed_cal={'strong':(.5,.5)},strong_only=True,seed=SEED+len(cells)*743)
      key=f'weak_{q}'
      cells[key]=experiment_cell(q,R,'targeted',true_cal={'strong':(.7,.7)},
          assumed_cal={'strong':(.7,.7)},strong_only=True,seed=SEED+len(cells)*743)
    # E1 + E2: distinct cross-world sign, same randomized arm probabilities.
    qs=np.linspace(.2,.4,41)
    fig1,ax=plt.subplots(figsize=(7.1,3.35))
    ax.plot(qs,[gap(q,0) for q in qs],label='Factual gap (lambda=0)')
    ax.plot(qs,[gap(q,1) for q in qs],label='Cross-world gap (lambda=1)')
    ax.axhline(0,linewidth=.8);ax.axvline(QSTAR,linestyle=':',linewidth=.8)
    ax.set(xlabel='Unobserved coupling q',ylabel='Expected candidate minus reference utility',title='E1-E2: identical factual kernels, opposite cross-world signs')
    ax.legend(loc='center left',fontsize=8)
    fig1.tight_layout();fig1.savefig(fig/'figure1.png',dpi=190);plt.close(fig1)
    # E3: strong, weak, zero information, plus robust calibration.
    fig2,ax=plt.subplots(figsize=(6.7,3.4))
    cats=['null','weak','robust','nominal']
    labs=['s=0','s=0.4','s=0.8; calibration interval','s=0.8; exact calibration']
    xs=np.arange(len(cats))
    for dx,q in [(-.15,.2),(.15,.4)]:
        ys=[cells[f'{c}_{q}' if c!='nominal' else f'nominal_{q}_targeted']['cert_rate'] for c in cats]
        ax.bar(xs+dx,ys,width=.3,label=f'q={q:.1f}')
    ax.set_xticks(xs,labs,rotation=16,ha='right');ax.set_ylim(0,1.05)
    ax.set(ylabel='Certificate probability by cost 12,000',title=f'E3: {R} synthetic repetitions per condition')
    ax.legend();fig2.tight_layout();fig2.savefig(fig/'figure2.png',dpi=190);plt.close(fig2)
    # E4: unconditional success by budget, no success-only cost bias.
    fig3,ax=plt.subplots(figsize=(6.7,3.3))
    for q in (.2,.4):
        for a in ('targeted','uniform'):
            vals=cells[f'nominal_{q}_{a}']['costs']
            budget=np.linspace(0,BUDGET,200)
            success=np.array([np.sum(np.isfinite(vals)&(vals<=b))/R for b in budget])
            ax.plot(budget,success,label=f'q={q:.1f}; {a}')
    ax.set(xlabel='Cumulative evidence cost',ylabel='Probability certified by budget',ylim=(0,1.03),title='E4: known-calibration synthetic proxy acquisition')
    ax.legend(fontsize=8);fig3.tight_layout();fig3.savefig(fig/'figure3.png',dpi=190);plt.close(fig3)
    # E5: exact shared-world bounds versus assumption-violating independent latent relaxation.
    share=lp_bounds();relax=lp_bounds(allow_dependence=True)
    fig4,ax=plt.subplots(figsize=(6.65,2.65))
    for y,(lo,hi),label in [(1,share,'Shared exogenous world (independence encoded)'),
                             (0,relax,'Relaxed latent coupling (assumption dropped)')]:
        ax.plot([lo,hi],[y,y],marker='o',linewidth=2,label=label)
    ax.axvline(0,linestyle=':',linewidth=.8)
    ax.set(xlabel='Sharp model-class gap interval',yticks=[],title='E5: LP bounds change when independence is omitted')
    ax.legend(loc='upper left',fontsize=7);fig4.tight_layout();fig4.savefig(fig/'figure4.png',dpi=190);plt.close(fig4)
    # E6: invalid alpha/beta can produce confident false positives.
    fig5,ax=plt.subplots(figsize=(6.7,3.15))
    categories=['Exact calibration','Calibration interval','Invalid plug-in','Noninformative (correctly specified)']
    for dx,q in [(-.17,.2),(.17,.4)]:
        keys=[f'nominal_{q}_targeted',f'robust_{q}',f'miscal_{q}',f'null_{q}']
        ax.bar(np.arange(4)+dx,[cells[k]['wrong_rate'] for k in keys],width=.34,label=f'q={q:.1f}')
    ax.set_xticks(range(4),categories,rotation=15,ha='right');ax.set_ylim(0,1.05)
    ax.set(ylabel='Wrong certificates / all independent repetitions',title='E6: misspecification is outside nominal guarantees')
    ax.legend();fig5.tight_layout();fig5.savefig(fig/'figure5.png',dpi=190);plt.close(fig5)
    summary={'seed':SEED,'R_per_cell':R,'budget':BUDGET,'delta':DELTA,'batch':BATCH,
      'factual':factual,'analytic':{'qstar':QSTAR,'gap_q02':gap(.2),'gap_q04':gap(.4),
        'gap_lambda0':gap(.2,0),'shared_lp':share,'relaxed_lp':relax},
      'cells':{k:strip_private(v) for k,v in cells.items()}}
    with open(out/'summary.json','w') as f:json.dump(summary,f,indent=2)
    with open(out/'replicates.csv','w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['condition','replicate','status','certification_cost','total_spent','censored_cost','ever_missed_true_q'])
        for k,r in cells.items():
            for i in range(R):writer.writerow([k,i,int(r['statuses'][i]),
                '' if not np.isfinite(r['costs'][i]) else float(r['costs'][i]),
                int(r['spent'][i]),float(r['costs'][i]) if np.isfinite(r['costs'][i]) else BUDGET,int(r['ever_missed_true_q'][i])])
    print('SYNTHETIC ONLY; no real-world data')
    print('R',R,'seed',SEED,'budget',BUDGET,'delta',DELTA)
    for k,r in cells.items():
        print(f"{k:25s} certified={r['certified']:4d} wrong={r['wrong']:4d} restricted_cost={r['restricted_mean_cost']:8.1f}")
    print('OUTPUT',out,fig)
if __name__=='__main__':main()
