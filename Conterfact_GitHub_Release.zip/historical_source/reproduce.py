"""Verify the archived synthetic study or regenerate all reported synthetic cells.

python reproduce.py --verify  # check immutable archive against SHA-256 and executable audits
python reproduce.py --rerun   # recreate full outputs with documented per-cell seeds

Only checks conditional simulations and software; not independent scientific review.
"""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def check_manifest() -> int:
    manifest = ROOT / "DATA_MANIFEST.sha256"
    if not manifest.is_file():
        raise FileNotFoundError(f"Missing {manifest.name} in extracted archive")
    entries = 0
    for record in manifest.read_text(encoding="utf-8").splitlines():
        if not record:
            continue
        digest, relative_path = record.split("  ", 1)
        candidate = (ROOT / relative_path).resolve()
        if not candidate.is_relative_to(ROOT.resolve()) or not candidate.is_file():
            raise RuntimeError(f"Missing or unsafe archived path: {relative_path}")
        actual = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if actual != digest:
            raise RuntimeError(f"SHA-256 mismatch: {relative_path}")
        entries += 1
    return entries


def check_seed_provenance() -> None:
    seed = json.loads((ROOT / "SEED_RULES.json").read_text())
    orig = json.loads((ROOT / "results/summary.json").read_text())
    dyn = json.loads((ROOT / "results/dynamic_summary.json").read_text())
    hard = json.loads((ROOT / "results/hard_summary.json").read_text())
    if orig["seed"] != seed["original"]["base_seed"] != 260917:
        raise AssertionError("Original result seed does not match declared runner")
    if orig["R_per_cell"] != 1000 or len(orig["cells"]) != 12:
        raise AssertionError("Original study count mismatch")
    if dyn["seed_rule"] != seed["composite"]["seed_rule"].replace(" + ", "+").replace(" * ", "*"):
        raise AssertionError("Composite seed rule mismatch")
    if dyn["R"] != 240 or len(dyn["cells"]) != 16:
        raise AssertionError("Composite study count mismatch")
    if hard["R"] != 500 or len(hard["hard"]) != 6 or len(hard["boundary"]) != 4:
        raise AssertionError("Hard/boundary study count mismatch")
    runners = {
        "run_experiments.py": ["SEED=260917", "SEED+len(cells)*743"],
        "dynamic_acquisition.py": ["270000+wi*10007+pi*997"],
        "hard_cases.py": ["280000+j*101", "290000+j*109"],
    }
    for name, expressions in runners.items():
        code = (ROOT / name).read_text(encoding="utf-8")
        for expr in expressions:
            if expr not in code:
                raise AssertionError(f"Seed expression missing from {name}: {expr}")
    print("PASS: original 260917, per-cell seed offsets, 12+16+6+4 cell counts match runners/results")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--verify", action="store_true", help="Verify archived hashes, seeds and numerical checks")
    action.add_argument("--rerun", action="store_true", help="Regenerate all synthetic records and run numerical checks")
    args = parser.parse_args()
    if args.verify:
        print(f"PASS: SHA-256 verified {check_manifest()} archived files", flush=True)
    check_seed_provenance()
    if args.rerun:
        for script in ("run_experiments.py", "dynamic_acquisition.py", "hard_cases.py"):
            print(f"Regenerating: {script}", flush=True)
            subprocess.run([sys.executable, script], cwd=ROOT, check=True)
    for script in ("theory_checks.py", "legacy_two_stage_checks.py", "upgrade_checks.py"):
        print(f"Checking: {script}", flush=True)
        subprocess.run([sys.executable, script], cwd=ROOT, check=True)
    print("PASS: synthetic archive reproduction checks completed; no real-world validation claimed", flush=True)


if __name__ == "__main__":
    main()
