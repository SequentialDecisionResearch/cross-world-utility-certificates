"""Auditable adaptive acquisition in a synthetic two-parameter proxy model.

Eligible sensor e in {plus, minus}: among Y1=0 units, sensitivity .9+sign*h,
false-positive rate .1+sign*h. Thus mean of W=1{Y1=0,Z=1} is
m_e(q,h)=.08+.8(q+sign*h), q in [.2,.4], h in [-.06,.06].
No unobserved pair of potential outcomes is passed to the learner. This is a
synthetic *joint calibration assumption*, not a real sensor validation.
"""
from __future__ import annotations
import argparse,csv,json,math
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=.08; S=.8; H=.06; QLO=.2; QHI=.4; QSTAR=.3
DELTA=.05; BATCH=200; PRICES=np.array([1.,1.6]); LABELS=('plus','minus')
ROOT=Path(__file__).resolve().parent

def radius(n, m=2, delta=DELTA):
    n=np.asarray(n,dtype=float)
    out=np.full_like(n,np.inf)
    mask=n>0
    out[mask]=np.sqrt(np.log(m*np.pi**2*n[mask]**2/(3*delta))/(2*n[mask]))
    return out

def bounds(counts, sums, delta=DELTA):
    """Exact 2D feasible q bounds by Fourier--Motzkin elimination of h.

    a<=q+h<=b; c<=q-h<=d; -H<=h<=H.
    If a stream was never sampled, its a,b (or c,d) are infinite.
    """
    n=np.asarray(counts,dtype=float)
    mu=np.divide(sums,n,out=np.zeros_like(n),where=n>0)
    r=radius(n,delta=delta)
    l=np.maximum(0,mu-r);u=np.minimum(1,mu+r)
    a=np.where(n[:,0]>0,(l[:,0]-BASE)/S,-np.inf)
    b=np.where(n[:,0]>0,(u[:,0]-BASE)/S,np.inf)
    c=np.where(n[:,1]>0,(l[:,1]-BASE)/S,-np.inf)
    d=np.where(n[:,1]>0,(u[:,1]-BASE)/S,np.inf)
    qlo=np.maximum.reduce((np.full(len(n),QLO),a-H,c-H,(a+c)/2))
    qhi=np.minimum.reduce((np.full(len(n),QHI),b+H,d+H,(b+d)/2))
    return qlo,qhi,(a,b,c,d)

def witness_h(q,a,b,c,d):
    lo=np.maximum.reduce((np.full(len(q),-H),a-q,q-d))
    hi=np.minimum.reduce((np.full(len(q), H),b-q,q-c))
    if np.any(lo>hi+1e-8):
        raise AssertionError('witness infeasible')
    return np.clip((lo+hi)/2,-H,H)

def bern_kl(p,q):
    p=np.clip(p,1e-12,1-1e-12)
    q=np.clip(q,1e-12,1-1e-12)
    return p*np.log(p/q)+(1-p)*np.log((1-p)/(1-q))

def select_channels(policy, t, active, counts, qlo,qhi,params):
    if policy=='uniform':
        return np.full(len(active),t%2,dtype=int)
    if policy=='static_plus':
        return np.zeros(len(active),dtype=int)
    if policy=='static_minus':
        return np.ones(len(active),dtype=int)
    a,b,c,d=params
    hm=witness_h(qlo,a,b,c,d)
    hp=witness_h(qhi,a,b,c,d)
    scores=np.zeros((len(active),2))
    for e,sign in enumerate((1,-1)):
        mlo=BASE+S*(qlo+sign*hm)
        mhi=BASE+S*(qhi+sign*hp)
        scores[:,e]=np.minimum(bern_kl(mlo,mhi),bern_kl(mhi,mlo))/PRICES[e]
    # Predetermined safeguard: every tenth batch goes to the less-sampled channel.
    # The data-dependent choices remain predictable relative to *future* units.
    if (t+1)%10==0:
        return np.argmin(counts[active],axis=1)
    return np.argmax(scores,axis=1)

def run_cell(q,h,policy,replications=200,budget=400000,seed=1,delta=DELTA,trace=False):
    rng=np.random.default_rng(seed)
    counts=np.zeros((replications,2),dtype=int)
    sums=np.zeros((replications,2),dtype=int)
    spent=np.zeros(replications,dtype=float)
    status=np.zeros(replications,dtype=int)
    certificate=np.full(replications,np.nan)
    misses=np.zeros(replications,dtype=bool)
    model_misses=np.zeros(replications,dtype=bool)
    switches=np.zeros(replications,dtype=int)
    prev=np.full(replications,-1,dtype=int)
    trace_rows=[]
    max_rounds=math.ceil(budget/(BATCH*min(PRICES)))+1
    for t in range(max_rounds):
        active=np.flatnonzero(status==0)
        if not len(active):break
        qlo,qhi,params=bounds(counts[active],sums[active],delta=delta)
        conflict=qlo>qhi+1e-9
        if np.any(conflict):
            status[active[conflict]]=2  # ModelConflict is an abstention, never a signature.
            active=active[~conflict]
            if not len(active):continue
            qlo,qhi,params=bounds(counts[active],sums[active],delta=delta)
        choices=select_channels(policy,t,active,counts,qlo,qhi,params)
        feasible=spent[active]+BATCH*PRICES[choices]<=budget+1e-8
        if not np.any(feasible):break
        active,choices=active[feasible],choices[feasible]
        for e,sign in enumerate((1.,-1.)):
            idx=active[choices==e]
            if not len(idx):continue
            m=BASE+S*(q+sign*h)
            assert 0<m<1
            sums[idx,e]+=rng.binomial(BATCH,m,size=len(idx))
            counts[idx,e]+=BATCH
            spent[idx]+=BATCH*PRICES[e]
            switches[idx]+=((prev[idx]>=0)&(prev[idx]!=e)).astype(int)
            prev[idx]=e
        qlo,qhi,_=bounds(counts[active],sums[active],delta=delta)
        bad=qlo>qhi+1e-9
        if np.any(bad):status[active[bad]]=2
        active=active[~bad];qlo=qlo[~bad];qhi=qhi[~bad]
        if not len(active):continue
        misses[active]|=(qlo>q+1e-10)|(qhi<q-1e-10)
        for e,sign in enumerate((1.,-1.)):
            idx=active[counts[active,e]>0]
            if len(idx):
                empirical=sums[idx,e]/counts[idx,e]
                rr=radius(counts[idx,e,None],delta=delta).ravel()
                real_mean=BASE+S*(q+sign*h)
                model_misses[idx]|=(empirical-rr>real_mean+1e-10)|(empirical+rr<real_mean-1e-10)
        pos=active[qlo>QSTAR+1e-10];neg=active[qhi<QSTAR-1e-10]
        status[pos]=1;status[neg]=-1
        cert=np.concatenate((pos,neg));certificate[cert]=spent[cert]
        if trace and t%15==0:
            ii=0
            trace_rows.append({'round':t,'qlo':float(bounds(counts[ii:ii+1],sums[ii:ii+1],delta=delta)[0][0]),
                              'qhi':float(bounds(counts[ii:ii+1],sums[ii:ii+1],delta=delta)[1][0]),
                              'n_plus':int(counts[ii,0]),'n_minus':int(counts[ii,1]),
                              'last_channel':LABELS[prev[ii]],'cost':float(spent[ii])})
    signed=np.isfinite(certificate)
    wrong=(np.abs(status)==1)&(status!=np.sign(q-QSTAR))
    censor=np.where(signed,certificate,budget)
    return {'q':q,'h':h,'allocation':policy,'R':replications,'budget':budget,'delta':delta,
            'signed':int(signed.sum()),'wrong':int(wrong.sum()),'abstained':int((~signed).sum()),
            'coverage_failures':int(misses.sum()),'full_model_coverage_failures':int(model_misses.sum()),
            'model_conflicts':int(np.sum(status==2)),'restricted_cost':float(censor.mean()),
            'restricted_cost_se':float(censor.std(ddof=1)/np.sqrt(replications)),
            'switches_mean':float(np.mean(switches)),
            'plus_frac':float(counts[:,0].sum()/max(1,counts.sum())),
            'n_plus_mean':float(counts[:,0].mean()),'n_minus_mean':float(counts[:,1].mean()),
            'cert_costs':certificate,'statuses':status,'costs':spent,'counts':counts,
            'misses':misses,'model_misses':model_misses,'trace':trace_rows}

def lp_reference(row):
    n=np.array([[row[0],row[1]]],dtype=float)
    summ=np.array([[row[2],row[3]]],dtype=float)
    qlo,qhi,(a,b,c,d)=bounds(n,summ)
    au=[];bu=[]
    for coeff,lower,upper in (([1,1],a[0],b[0]),([1,-1],c[0],d[0])):
        if np.isfinite(upper):au.append(coeff);bu.append(upper)
        if np.isfinite(lower):au.append([-x for x in coeff]);bu.append(-lower)
    lo=linprog([1,0],A_ub=au if au else None,b_ub=bu if au else None,bounds=[(QLO,QHI),(-H,H)],method='highs')
    hi=linprog([-1,0],A_ub=au if au else None,b_ub=bu if au else None,bounds=[(QLO,QHI),(-H,H)],method='highs')
    if not(lo.success and hi.success):raise AssertionError('reference LP infeasible')
    assert np.isclose(qlo[0],lo.fun,atol=1e-8) and np.isclose(qhi[0],-hi.fun,atol=1e-8),(row,qlo,qhi,lo.fun,-hi.fun)
    return float(qlo[0]),float(qhi[0])

def strip(r):
    return {k:v for k,v in r.items() if k not in ('cert_costs','statuses','costs','counts','misses','model_misses','trace')}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--quick',action='store_true')
    args=parser.parse_args()
    R=24 if args.quick else 240
    out=ROOT/('results_quick' if args.quick else 'results')
    figs=ROOT/('figures_quick' if args.quick else 'figures')
    out.mkdir(exist_ok=True);figs.mkdir(exist_ok=True)
    # Both directions of nuisance, and two decision margins.
    worlds=[(.25,.05),(.35,-.05),(.28,.05),(.32,-.05)]
    policies=['witness','uniform','static_plus','static_minus']
    rows=[]; allcells={}; traces=[]
    for wi,(q,h) in enumerate(worlds):
        for pi,policy in enumerate(policies):
            key=f'q{q:.2f}_h{h:+.2f}_{policy}'
            r=run_cell(q,h,policy,R,400000,seed=270000+wi*10007+pi*997,trace=policy=='witness')
            allcells[key]=r
            print(key,'signed',r['signed'],'wrong',r['wrong'],'restricted',round(r['restricted_cost']),
                  'plus_frac',round(r['plus_frac'],3),'switch',round(r['switches_mean'],2),flush=True)
            for i in range(R):
                rows.append([key,i,q,h,policy,int(r['statuses'][i]),
                             '' if not np.isfinite(r['cert_costs'][i]) else float(r['cert_costs'][i]),
                             float(r['costs'][i]),float(r['cert_costs'][i]) if np.isfinite(r['cert_costs'][i]) else 400000,
                             int(r['counts'][i,0]),int(r['counts'][i,1]),int(r['misses'][i]),int(r['model_misses'][i])])
            for tr in r['trace']:
                traces.append({'condition':key,**tr})
    with open(out/'dynamic_replicates.csv','w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['condition','replicate','q','h','policy','status','certificate_cost','spent','censored_cost','n_plus','n_minus','ever_missed_q','ever_missed_full_model']);writer.writerows(rows)
    with open(out/'dynamic_trace.json','w') as f:json.dump(traces,f,indent=2)
    summ={'seed_rule':'270000+world_index*10007+policy_index*997',
          'R':R,'budget':400000,'delta':DELTA,'batch':BATCH,
          'worlds':worlds,'prices':PRICES.tolist(),
          'cells':{k:strip(v) for k,v in allcells.items()}}
    with open(out/'dynamic_summary.json','w') as f:json.dump(summ,f,indent=2)
    # Plot success by cost for compositional hard margin worlds, censoring included.
    fig,ax=plt.subplots(figsize=(7.2,3.6))
    for policy in policies:
        key=f'q0.28_h+0.05_{policy}'
        costs=allcells[key]['cert_costs']
        bins=np.linspace(0,400000,180)
        ax.plot(bins,[(np.isfinite(costs)&(costs<=b)).mean() for b in bins],label=policy)
    ax.set(xlabel='Cumulative synthetic cost',ylabel='Unconditional certificate probability',
           title='Composite q,h: adaptive witness allocation versus fixed baselines',ylim=(0,1.04))
    ax.legend(fontsize=8);fig.tight_layout();fig.savefig(figs/'figure_dynamic.png',dpi=195);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.2,3.1))
    groups=['q=.25, h=.05','q=.35, h=-.05','q=.28, h=.05','q=.32, h=-.05']
    xs=np.arange(4)
    for i,policy in enumerate(('witness','uniform')):
        ys=[allcells[f'q{q:.2f}_h{h:+.2f}_{policy}']['restricted_cost'] for q,h in worlds]
        ax.bar(xs+(i-.5)*.35,ys,width=.35,label=policy)
    ax.set(xticks=xs,xticklabels=groups,ylabel='Restricted mean cost, cap 400,000',
           title='Composite benchmark: all noncertifications charged full cap')
    ax.legend();fig.tight_layout();fig.savefig(figs/'figure_dynamic_cost.png',dpi=195);plt.close(fig)
    print('WROTE',len(rows),'records; q,h composite synthetic only')

if __name__=='__main__':main()
