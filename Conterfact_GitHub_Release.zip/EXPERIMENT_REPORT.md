# E7-E9: Evidence sufficiency and costed sign certification

Executed synthetic experiments accompanying *Decision Certificates for Cross-World Utilities in Finite-Horizon Policies*. The results below were generated from saved replicate-level records.

## Experimental setting

- **Underlying SCM:** the original irreversibly branched two-potential-outcome model. For the fixed candidate/reference policies, the gap has the sign of `q - 0.3`; all original model constants and the two linked-offset sensor laws are reused.
- **Available observations:** per purchased unit, only a single-world factual feature or binary proxy observation is disclosed. No paired latent `(Y0,Y1)` label is available to a learner.
- **Error/abstention:** nominal sign error level `delta=0.05`; the composite lower bound is stated for hypothetical rules satisfying both `delta=0.05` and `beta_abs=0.10` *uniformly* over the full finite model class.
- **Replications:** E7 1,000 per cell (32 cells), E8 400 per cell (6 cells), E9 300 per cell (40 cells). Random seeds, scripts, and raw records are in the archive.

## E7: a sign-informative evidence channel is necessary

Here `Theta={q=0.25,q=0.35}`. Factual `Y1` and an uninformative proxy have the same observation laws in both models. The weak proxy uses `alpha=beta=0.7`, the strong proxy uses `alpha=beta=0.9`. A forced decision classifies the sample mean against the model midpoint; a conservative fixed-sample certificate issues a sign only when a Hoeffding interval excludes the midpoint.

| Channel | Per-model mean gap g | Theorem sufficient n | Certified at n=5,000 | Certified at n=20,000 | Forced error at n=20,000 |
|---|---:|---:|---:|---:|---:|
| factual | 0.000 | not finite | 0.000 | 0.000 | 0.495 |
| uninformative_proxy | 0.000 | not finite | 0.000 | 0.000 | 0.504 |
| weak_proxy | 0.040 | 18445 | 0.535 | 0.998 | 0.000 |
| strong_proxy | 0.080 | 4612 | 1.000 | 1.000 | 0.000 |


The noninformative channels produced no valid signs at any studied sample size; a forced randomized sign stayed near 50% error. For the informative channels, certification increased with sample size. All E7 sign certificates recorded zero wrong signs; that finite observation does not prove a zero error probability. Theorem's sufficient `n` is conservative, rather than an observed threshold.

![](figures/e7_certification.png)

![](figures/e7_forced_error.png)

## E8: geometric separation and sufficient stopping time

The structural class is `q in [0.2,0.4]`, `h in [-0.06,0.06]` and the observable features are the two original linked-offset Bernoulli sensor means `m_plus=0.08+0.8(q+h)`, `m_minus=0.08+0.8(q-h)`. The opposite-sign set is `q<=0.3` or `q>=0.3`. An independent LP gives `kappa = 0.8*abs(q-0.3)`. The stated `n_star` is the *smallest integer* satisfying `2*r_n < kappa`; it is a sufficient per-sensor sample size, not a minimax or expected-time bound.

| q | h | kappa | Theorem n_star | Median observed n | Certified / 400 | Wrong |
|---:|---:|---:|---:|---:|---:|---:|
| 0.22 | +0.00 | 0.064 | 11,515 | 3,000 | 400/400 | 0 |
| 0.25 | +0.05 | 0.040 | 32,037 | 8,000 | 400/400 | 0 |
| 0.28 | -0.05 | 0.016 | 231,102 | 53,000 | 400/400 | 0 |
| 0.32 | +0.05 | 0.016 | 231,102 | 52,000 | 400/400 | 0 |
| 0.35 | -0.05 | 0.040 | 32,037 | 7,000 | 400/400 | 0 |
| 0.38 | +0.00 | 0.064 | 11,515 | 3,000 | 400/400 | 0 |


All 2,400 E8 runs certified within the shared cap, with no observed wrong signs. The earlier empirical stop than `n_star` is consistent with `n_star` being sufficient. No coverage-preserving path failed to certify by its separation threshold. Both signs were evaluated. The cap was common across all models, and the learner used neither the true `q,h` nor its `kappa` to select observations.

![](figures/e8_certification_threshold.png)

![](figures/e8_cost_separation.png)

## E9: composite alternatives and evidence-cost allocation

The finite class contains eight models: `q in {0.25,0.28,0.32,0.35}` and `h in {-0.05,+0.05}`. Each of five strategies faces the same model menu and sensor prices `(1,1.6)`, with a common maximum expenditure of 80,000. The sign decision is made using an anytime likelihood-ratio confidence set, with threshold `log((|Theta|-1)/delta)`. The adaptive strategy uses past likelihoods and periodic exploration; pooled-mix weights are frozen before data. The true-model-specific LP weights are *only* an information lower-bound benchmark and are never used by a deployed comparator.

| Allocation | Certificates / 2,400 | Wrong / 2,400 | Balanced restricted mean cost | Across-model SE |
|---|---:|---:|---:|---:|
| adaptive | 2,400/2,400 | 9/2,400 | 1,669.0 | 21.1 |
| uniform | 2,400/2,400 | 10/2,400 | 1,846.9 | 25.6 |
| pooled_mix | 2,400/2,400 | 11/2,400 | 2,435.9 | 36.8 |
| static_plus | 1,801/2,400 | 7/2,400 | 21,863.9 | 40.6 |
| static_minus | 1,805/2,400 | 7/2,400 | 22,968.3 | 78.8 |


The balanced eight-model restricted mean for adaptive allocation was 1,669.0 cost units, compared with 1,846.9 for alternating uniform allocation. The unpaired difference, uniform minus adaptive, was 177.9 (9.6% of the uniform mean); the exploratory, unadjusted 95% normal approximation across eight fixed worlds was [112.8, 243.0]. Results are *not uniformly favorable*: individual model cells can reverse the ranking. Single-sensor strategies suffered large abstention rates in worlds for which an opposite-sign model has the same selected sensor law.

![](figures/e9_restricted_cost_by_model.png)

![](figures/e9_abstention_by_model.png)

### Interpretation of the cost lower bound

For each true model `theta`, the oracle information LP computes `I_star(theta)` using KL divergences against *all* opposite-sign alternatives. The benchmark `kl(1-beta_abs-delta,delta)/I_star(theta)` applies to a procedure only when it meets the required error and abstention limits **uniformly over the full hypothesis class**. Empirical sign rates of 300/300 cannot establish a uniform `beta_abs<=0.10` guarantee, and some single-sensor strategies plainly violate that prerequisite. Thus the plotted ratio is descriptive; it is not a formal efficiency ratio or proof of bound attainment. The cost LP was independently checked against a dense one-dimensional cost-fraction grid for each true model.

![](figures/e9_cost_vs_conditional_lower_bound.png)

## Comparison with the earlier executed study

The original archive contains 12,000 E1-E6 replicate records and 3,840 composite-allocation records. E9 deliberately reuses their joint-offset Bernoulli sensor mechanism, selected truths, and unit prices. `results/comparison_legacy_matching_worlds.csv` shows both data sets side by side for matching `(q,h)`. **The costs are not directly comparable as improvements:** the previous study uses a continuous feasible `(q,h)` set, a different confidence rule and a 400,000 cap; E9 uses a known *eight-point* hypothesis class, likelihood-ratio certification and an 80,000 cap. Its lower numerical costs do not demonstrate a better method for the previous problem.

## Verification and limitations

- Original source and output records are included unchanged under `historical_source/`. Existing executable audit tools remain available.
- The new batch runner saves each completed condition separately; rerunning uses matching source/configuration fingerprints to skip completed cells.
- Every replicate is present in E7--E9 CSV files and per-cell files. Counts were reconciled with summary totals; LP identities, thresholds, and the implication 'wrong certificate => coverage failure' were checked.
- All observations are synthetic or model-implied Bernoulli draws. No human preference data, real cross-world sensor calibration, unmodeled h drift or independent-machine replication is represented as completed.
- A formal significance claim about policy superiority would require a predeclared primary contrast, multiplicity handling and broader model classes. Neither finite simulations nor empirical rare-event counts establish universal error probabilities.

## Reproduction
```bash
python -m unittest discover -s experiment_code -p 'test_*.py' -v
python experiment_code/run_e7_e9.py --verify-only
python experiment_code/run_e7_e9.py
python experiment_code/summarize_and_plot.py
cd historical_source && python reproduce.py --verify
```

