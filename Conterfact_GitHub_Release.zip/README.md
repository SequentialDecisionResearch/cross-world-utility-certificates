# Decision Certificates for Cross-World Utilities in Finite-Horizon Policies

Code and synthetic data accompanying the manuscript by Shenggang Li, Bilian Song, Yunfeng Qi, and Joseph Li.

The repository reproduces the computational checks and synthetic experiments E1–E9 reported in the manuscript. It does **not** contain human-subject observations or evidence from a deployed decision system. The cross-world proxy calibrations and linked-offset structure are assumptions of the synthetic generators.

## Scope

| Directory | Reproducibility material |
| --- | --- |
| `historical_source/` | Original E1–E6 source, mathematical checks, four-stage historical result collections, per-replication files, figures, seed rules and SHA-256 audit. |
| `experiment_code/` | Executable E7–E9 simulations, independent output audit, unit tests, and figure regeneration. |
| `results/` | Complete E7–E9 replicate-level CSVs (46,400 records), 78 condition checkpoints, summaries, experiment design and information calculations. |
| `figures/` | Seven E7–E9 figures generated from the supplied records. |
| `EXPERIMENT_REPORT.md` | Numerical interpretation, comparisons and limitations. |

The repository deliberately omits superseded manuscript drafts, auxiliary submission ZIPs, development caches, local tool helpers and exploratory quick-run outputs. The current journal PDF and its separately submitted online appendix are distributed with the manuscript, not duplicated here.

## Verification without rerunning simulations

Use Python 3.10+; tested with Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s experiment_code -p 'test_*.py' -v
python experiment_code/run_e7_e9.py --verify-only
python experiment_code/audit_output.py
cd historical_source
python reproduce.py --verify
```

The historical checksum audit uses `historical_source/DATA_MANIFEST.sha256`. The E7–E9 audit independently checks raw replication rows, cell checkpoints, summaries and figures. A successful check establishes internal reproduction of this synthetic archive; it does not validate the scientific calibration assumptions.

## Rerunning and plotting

From the repository root:

```bash
python experiment_code/run_e7_e9.py
python experiment_code/summarize_and_plot.py
```

The E7–E9 runner saves completed condition checkpoints and skips verified cells on a warm rerun. To regenerate the older experiments, run `python reproduce.py --rerun` from `historical_source/` (this overwrites regenerated historical outputs). Results use deterministic, documented seed rules; the E9 strategy comparisons use independent rather than paired Monte Carlo seeds.

## Interpretation and limitations

- E7 tests distinguishability of two opposite-sign models under synthetic informative and uninformative Bernoulli channels.
- E8 tests the stopping-time dependence on observable separation within a specified linked-offset binary sensor model.
- E9 compares evidence allocation under a declared eight-model class and common budget, with abstention charged in restricted cost.
- The earlier composite Witness experiment differs in model class and budget from E9. Its costs should not be interpreted as a before/after algorithm improvement.
- This repository contains no measured field calibration of cross-world proxy sensitivity or specificity. Confidence guarantees only apply under the stated data-generating and calibration conditions.

Please cite the paper if using the code or figures. No reuse license is granted by this repository unless the authors add one separately.
