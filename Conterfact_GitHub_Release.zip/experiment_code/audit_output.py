#!/usr/bin/env python3
"""Independent CSV-level E7--E9 audit, deliberately separate from the simulator.

Exit nonzero if row counts, checkpoint contents, sampling budgets, or summaries
disagree. This does not establish population error rates from finite simulation.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def almost(a, b, atol=1e-7):
    return math.isclose(float(a), float(b), abs_tol=atol, rel_tol=1e-8)


def key(stage, row):
    if stage == "e7":
        return row["channel"], int(row["n"]), float(row["q"])
    if stage == "e8":
        return float(row["q"]), float(row["h"])
    return int(row["true_index"]), row["policy"]


def check_stage(stage, expected_replications, expected_cells):
    summaries = read_csv(OUT / f"{stage}_summary.csv")
    records = read_csv(OUT / f"{stage}_replicates.csv")
    checkpoints = sorted((OUT / "cells" / stage.upper()).glob("*.csv"))
    assert len(summaries) == expected_cells, (stage, len(summaries))
    assert len(checkpoints) == expected_cells, (stage, len(checkpoints))
    assert len(records) == expected_cells * expected_replications
    grouped = defaultdict(list)
    for rec in records:
        grouped[key(stage, rec)].append(rec)
    assert len(grouped) == expected_cells
    for checkpoint in checkpoints:
        rows = read_csv(checkpoint)
        meta = json.loads(checkpoint.with_suffix(".json").read_text())
        assert meta["status"] == "completed" and meta["record_count"] == expected_replications
        assert len(rows) == expected_replications
        cellkey = key(stage, rows[0])
        assert Counter(tuple(sorted(r.items())) for r in rows) == Counter(
            tuple(sorted(r.items())) for r in grouped[cellkey]
        ), checkpoint
    for summary in summaries:
        cell = grouped[key(stage, summary)]
        assert len(cell) == int(summary["R"]) == expected_replications
        assert set(int(row["replicate"]) for row in cell) == set(range(expected_replications))
        assert len(set(row["seed"] for row in cell)) == 1
        if stage == "e7":
            check_e7(cell, summary)
        elif stage == "e8":
            check_e8(cell, summary)
        else:
            check_e9(cell, summary)
    print(f"PASS {stage.upper()}: {expected_cells} cells, {len(records):,} records, "
          f"{len(checkpoints)} matching completed checkpoints")


def check_e7(cell, summary):
    certified = sum(int(r["certified_sign"]) != 0 for r in cell)
    forced_wrong = sum(int(r["forced_wrong"]) for r in cell)
    wrong = sum(int(r["certified_wrong"]) for r in cell)
    misses = sum(int(r["confidence_miss"]) for r in cell)
    assert certified == int(summary["certified"])
    assert forced_wrong == int(summary["forced_wrong"])
    assert wrong == int(summary["certified_wrong"])
    assert misses == int(summary["coverage_misses"])
    for rec in cell:
        sign = int(rec["certified_sign"])
        truth = int(rec["true_sign"])
        assert sign in (-1, 0, 1)
        assert int(rec["certified_wrong"]) == int(sign != 0 and sign != truth)
        assert not int(rec["certified_wrong"]) or int(rec["confidence_miss"])
        assert 0 <= float(rec["sample_mean"]) <= 1


def check_e8(cell, summary):
    certified = sum(int(r["certified"]) for r in cell)
    wrong = sum(int(r["wrong_sign"]) for r in cell)
    misses = sum(int(r["ever_missed_true_model"]) for r in cell)
    assert certified == int(summary["certified"])
    assert wrong == int(summary["wrong"])
    assert misses == int(summary["ever_missed_true_model"])
    assert almost(sum(float(r["restricted_cost"]) for r in cell)/len(cell),
                  summary["mean_restricted_cost"])
    assert almost(summary["kappa_lp"], summary["kappa_formula"])
    cap = float(summary["cost_cap"])
    for rec in cell:
        assert int(rec["n_plus"]) == int(rec["n_minus"])
        assert int(rec["n_plus"]) % int(summary["batch"]) == 0
        assert almost(float(rec["actual_spent"]),
                      (int(rec["n_plus"]) + 1.6*int(rec["n_minus"])))
        assert float(rec["restricted_cost"]) <= cap + 1e-7
        assert not int(rec["wrong_sign"]) or int(rec["ever_missed_true_model"])
        if int(rec["certified"]):
            assert int(rec["first_cert_n_each"]) == int(rec["n_plus"])


def check_e9(cell, summary):
    certified = sum(int(r["certified"]) for r in cell)
    wrong = sum(int(r["wrong_sign"]) for r in cell)
    excluded = sum(int(r["ever_excluded_true_model"]) for r in cell)
    assert certified == int(summary["certified"])
    assert wrong == int(summary["wrong"])
    assert excluded == int(summary["ever_excluded_true_model"])
    assert almost(sum(float(r["restricted_cost"]) for r in cell)/len(cell),
                  summary["mean_restricted_cost"])
    budget = float(summary["budget"])
    for rec in cell:
        signed = int(rec["signed_status"])
        truth = int(rec["correct_sign"])
        assert signed in (-1, 0, 1)
        assert int(rec["certified"]) == int(signed != 0)
        assert int(rec["wrong_sign"]) == int(signed != 0 and signed != truth)
        assert not int(rec["wrong_sign"]) or int(rec["ever_excluded_true_model"])
        cost = int(rec["n_plus"]) + 1.6*int(rec["n_minus"])
        assert almost(cost, rec["actual_spent"])
        assert cost <= budget + 1e-7
        assert int(rec["n_plus"]) % int(summary["batch"]) == 0
        assert int(rec["n_minus"]) % int(summary["batch"]) == 0
        assert almost(rec["restricted_cost"], cost if signed else budget)


def main():
    design = json.loads((OUT / "design.json").read_text())
    assert design["quick"] is False
    assert design["repetitions"] == {"E7": 1000, "E8": 400, "E9": 300}
    check_stage("e7", 1000, 32)
    check_stage("e8", 400, 6)
    check_stage("e9", 300, 40)
    theory = json.loads((OUT / "e9_oracle_information.json").read_text())
    assert len(theory) == 8
    for record in theory:
        assert record["I_star"] > 0
        assert abs(record["I_star"]-record["brute_grid_I"]) < 5e-5
        assert almost(record["oracle_cost_fraction_plus"] +
                      record["oracle_cost_fraction_minus"], 1)
    historical = json.loads((OUT / "historical_reference.json").read_text())
    assert historical["original_replicate_count"] == 12000
    assert historical["original_dynamic_replicate_count"] == 3840
    assert len(read_csv(ROOT / "historical_source" / "results" / "replicates.csv")) == 12000
    assert len(read_csv(ROOT / "historical_source" / "results" / "dynamic_replicates.csv")) == 3840
    for fig in sorted((ROOT / "figures").glob("*.png")):
        with fig.open("rb") as handle:
            assert handle.read(8) == b"\x89PNG\r\n\x1a\n", fig
        assert fig.stat().st_size > 8000, fig
    assert len(list((ROOT / "figures").glob("*.png"))) == 7
    text = (ROOT / "EXPERIMENT_REPORT.md").read_text()
    assert "../figures" not in text
    for fig in (ROOT / "figures").glob("*.png"):
        assert f"figures/{fig.name}" in text
    sha = hashlib.sha256((ROOT / "experiment_code" / "run_e7_e9.py").read_bytes()).hexdigest()
    assert len(sha) == 64
    print("PASS LP oracle vs 4001-grid search; legacy counts; PNG signatures; report links")
    print("AUDIT COMPLETE: independent record/checkpoint/summary consistency checks passed")


if __name__ == "__main__":
    main()
