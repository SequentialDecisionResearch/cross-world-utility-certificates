#!/usr/bin/env python3
"""Executed E7-E9 synthetic experiments for fixed-pair counterfactual certificates.

All outcomes are generated from eligible *single-world* channel observation laws.
The experiment runner sees the true q,h only to generate samples and score results.
The sequential decision rules never receive the true model index.

Usage:
    python experiment_code/run_e7_e9.py --quick
    python experiment_code/run_e7_e9.py
    python experiment_code/run_e7_e9.py --verify-only
Completed cells are cached with configuration and source fingerprints.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "historical_source"))
from dynamic_acquisition import BASE as SENSOR_BASE, S, H, QSTAR, PRICES, bounds, radius
from model import gap, proxy_mean

DELTA = 0.05
BETA_ABS = 0.10
E7_NS = (250, 1000, 5000, 20000)
E7_CHANNELS = ("factual", "uninformative_proxy", "weak_proxy", "strong_proxy")
E8_WORLDS = ((0.25, 0.05), (0.28, -0.05), (0.32, 0.05), (0.35, -0.05),
             (0.22, 0.00), (0.38, 0.00))
E9_THETAS = tuple((q, h) for q in (0.25, 0.28, 0.32, 0.35) for h in (-0.05, 0.05))
E9_POLICIES = ("adaptive", "pooled_mix", "uniform", "static_plus", "static_minus")


def source_fingerprint() -> str:
    digest = hashlib.sha256()
    for p in (Path(__file__), BASE / "historical_source" / "model.py",
              BASE / "historical_source" / "dynamic_acquisition.py"):
        digest.update(p.read_bytes())
    return digest.hexdigest()


def config_fingerprint(params: dict) -> str:
    return hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()


def dump_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temp.replace(path)


def dump_csv(path: Path, rows: list[dict]) -> None:
    assert rows, f"Empty CSV requested: {path}"
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    names = list(rows[0])
    with temp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=names, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def run_cached(stage: str, key: str, params: dict, output: Path, func):
    # Build extensions by concatenation: pathlib.with_suffix() would mistake
    # q0.25 for a ".25" suffix, collapsing distinct cells (q=.25 and .35).
    cell_dir = output / "cells" / stage
    meta_path = cell_dir / f"{key}.json"
    csv_path = cell_dir / f"{key}.csv"
    fingerprint = config_fingerprint({"params": params, "source": source_fingerprint()})
    if meta_path.is_file() and csv_path.is_file():
        old = json.loads(meta_path.read_text())
        if old.get("fingerprint") == fingerprint:
            return old["summary"], read_csv(csv_path), True
    summary, rows = func(**params)
    dump_csv(csv_path, rows)
    dump_json(meta_path, {"fingerprint": fingerprint, "params": params, "summary": summary,
                          "record_count": len(rows), "status": "completed"})
    return summary, [{k: str(v) for k, v in row.items()} for row in rows], False


def wilson(k: int, n: int, z: float = 1.95996398454) -> tuple[float, float]:
    """Two-sided 95% Wilson score interval."""
    if not n:
        return (float("nan"), float("nan"))
    p = k / n
    a = 1 + z*z/n
    mid = (p + z*z/(2*n)) / a
    half = z * math.sqrt((p*(1-p)+z*z/(4*n))/n)/a
    return (max(0.0, mid-half), min(1.0, mid+half))


def e7_observable_mean(channel: str, q: float) -> float:
    if channel == "factual":
        return 0.2  # Y1; factual law has no q dependence
    ab = {"uninformative_proxy": .5, "weak_proxy": .7, "strong_proxy": .9}[channel]
    return proxy_mean(q, alpha=ab, beta=ab)


def e7_cell(channel: str, n: int, q: float, R: int, seed: int):
    assert q in (0.25, 0.35) and n > 0 and R > 0
    rng = np.random.default_rng(seed)
    p_neg = e7_observable_mean(channel, .25)
    p_pos = e7_observable_mean(channel, .35)
    true_sign = -1 if q < QSTAR else +1
    p_true = e7_observable_mean(channel, q)
    g = abs(p_pos-p_neg)
    means = rng.binomial(n, p_true, size=R) / n
    r = math.sqrt(math.log(2/DELTA)/(2*n))
    if g > 1e-12:
        midpoint = (p_neg+p_pos)/2
        forced = np.where(means > midpoint, +1, -1)
        certified = np.where(means > midpoint+r, +1,
                             np.where(means < midpoint-r, -1, 0))
        theorem_n = math.ceil(8/(g*g) * math.log(2/DELTA))
    else:
        midpoint = p_true
        forced = np.where(rng.random(R) < .5, +1, -1)
        certified = np.zeros(R, dtype=int)
        theorem_n = None
    forced_wrong = forced != true_sign
    cert_wrong = (certified != 0) & (certified != true_sign)
    coverage_fail = np.abs(means-p_true) > r
    assert not np.any(cert_wrong & ~coverage_fail)
    records = []
    for i in range(R):
        records.append({
            "replicate": i, "seed": seed, "channel": channel, "n": n, "q": q,
            "true_sign": true_sign, "true_mean": p_true, "sample_mean": float(means[i]),
            "forced_sign": int(forced[i]), "forced_wrong": int(forced_wrong[i]),
            "certified_sign": int(certified[i]), "certified_wrong": int(cert_wrong[i]),
            "confidence_miss": int(coverage_fail[i]), "g": g, "radius": r,
        })
    k_f = int(forced_wrong.sum())
    k_c = int(cert_wrong.sum())
    k_s = int(np.count_nonzero(certified))
    summary = {"experiment": "E7", "channel": channel, "n": n, "q": q,
               "R": R, "true_sign": true_sign, "g": g, "r_fixed": r,
               "theorem_A_n_sufficient": theorem_n,
               "forced_wrong": k_f, "forced_wrong_rate": k_f/R,
               "forced_wrong_wilson95": wilson(k_f, R),
               "certified": k_s, "certified_rate": k_s/R,
               "certified_wilson95": wilson(k_s, R),
               "certified_wrong": k_c, "certified_wrong_rate": k_c/R,
               "coverage_misses": int(coverage_fail.sum())}
    return summary, records


def positive_radius(n: int, delta: float = DELTA) -> float:
    assert n >= 1
    return math.sqrt(math.log(2*math.pi**2*n*n/(3*delta))/(2*n))


def separation_threshold(kappa: float) -> int:
    """Smallest integer n with 2*r_n < kappa for M=2 time-uniform streams."""
    assert kappa > 0
    upper = 1
    while 2*positive_radius(upper) >= kappa:
        upper *= 2
        if upper >= 2_000_000_000:
            raise ValueError("Separation requires an impractical sample count")
    lower = 0
    while lower + 1 < upper:
        mid = (lower+upper)//2
        if 2*positive_radius(mid) < kappa:
            upper = mid
        else:
            lower = mid
    return upper


def e8_lp_kappa(q: float, h: float) -> float:
    """LP with variables (q_adverse,h_adverse,t); min infinity-norm mean gap."""
    sign = np.sign(q-QSTAR)
    assert sign != 0
    # |S[(q'-q) +/- (h'-h)]| <= t.
    aq = []
    bq = []
    for sgn in (1.0, -1.0):
        for direction in (1.0, -1.0):
            aq.append([direction*S, direction*S*sgn, -1.0])
            bq.append(direction*S*(q+sgn*h))
    q_bounds = ((.2, QSTAR) if sign > 0 else (QSTAR, .4))
    lp = linprog([0.0, 0.0, 1.0], A_ub=aq, b_ub=bq,
                 bounds=[q_bounds, (-H, H), (0, None)], method="highs")
    if not lp.success:
        raise RuntimeError(lp.message)
    return float(lp.fun)


def e8_cell(q: float, h: float, R: int, seed: int, batch: int, common_cap_n: int):
    """Round-robin sampling using exactly the existing linked-offset projection."""
    assert .2 <= q <= .4 and abs(h) <= H
    rng = np.random.default_rng(seed)
    margin = abs(q-QSTAR)
    kappa = e8_lp_kappa(q, h)
    assert abs(kappa - S*margin) < 1e-8, (kappa, margin)
    n_star = separation_threshold(kappa)
    cap_n = common_cap_n
    assert cap_n >= n_star and cap_n % batch == 0
    counts = np.zeros((R, 2), dtype=int)
    successes = np.zeros((R, 2), dtype=int)
    sign = np.zeros(R, dtype=int)
    cert_n = np.full(R, -1, dtype=int)
    ever_missed_true_model = np.zeros(R, dtype=bool)
    ever_missed_q = np.zeros(R, dtype=bool)
    true_sign = int(np.sign(q-QSTAR))
    true_means = np.array([SENSOR_BASE+S*(q+h), SENSOR_BASE+S*(q-h)])
    for n in range(batch, cap_n+1, batch):
        active = np.flatnonzero(sign == 0)
        if active.size == 0:
            break
        draws = rng.binomial(batch, true_means, size=(len(active), 2))
        successes[active] += draws
        counts[active] += batch
        qlow, qhigh, _ = bounds(counts[active], successes[active], delta=DELTA)
        rr = positive_radius(n)
        observed = successes[active]/counts[active]
        ever_missed_true_model[active] |= np.any(
            np.abs(observed-true_means[None,:]) > rr+1e-12, axis=1)
        ever_missed_q[active] |= (qlow > q+1e-10) | (qhigh < q-1e-10)
        now = np.where(qlow > QSTAR+1e-10, +1,
                       np.where(qhigh < QSTAR-1e-10, -1, 0))
        conflict = qlow > qhigh+1e-8
        if np.any(conflict & (now != 0)):
            raise AssertionError("ModelConflict was signed")
        now[conflict] = 2
        done = now != 0
        sign[active[done]] = now[done]
        cert_n[active[done]] = n
    # On the coverage event, the theorem's strict 2r < kappa rule is decisive.
    outstanding = (sign == 0) & (~ever_missed_true_model)
    if outstanding.any():
        raise AssertionError(f"E8: {outstanding.sum()} full-coverage paths failed at n_star")
    wrong = (np.abs(sign) == 1) & (sign != true_sign)
    if np.any(wrong & (~ever_missed_true_model)):
        raise AssertionError("E8 wrong certificate on full coverage event")
    certified = np.abs(sign) == 1
    spent_n = counts[:,0]
    assert np.array_equal(counts[:,0], counts[:,1])
    cap_cost = cap_n*float(PRICES.sum())
    actual_cost = spent_n*float(PRICES.sum())
    restricted_cost = np.where(certified, actual_cost, cap_cost)
    records = []
    for i in range(R):
        records.append({
            "replicate": i, "seed": seed, "q": q, "h": h, "true_sign": true_sign,
            "signed_status": int(sign[i]), "certified": int(certified[i]),
            "wrong_sign": int(wrong[i]), "first_cert_n_each": int(cert_n[i]),
            "n_plus": int(counts[i,0]), "n_minus": int(counts[i,1]),
            "actual_spent": float(actual_cost[i]),
            "restricted_cost": float(restricted_cost[i]),
            "ever_missed_true_model": int(ever_missed_true_model[i]),
            "ever_missed_q": int(ever_missed_q[i]),
        })
    summary = {
        "experiment": "E8", "q": q, "h": h, "R": R, "batch": batch,
        "true_sign": true_sign, "margin_q": margin, "kappa_lp": kappa,
        "kappa_formula": S*margin, "n_sufficient_per_channel": n_star,
        "cost_sufficient_bound": n_star*float(PRICES.sum()),
        "n_cap_per_channel": cap_n, "cost_cap": cap_cost,
        "certified": int(certified.sum()), "certified_rate": float(certified.mean()),
        "wrong": int(wrong.sum()), "wrong_rate": float(wrong.mean()),
        "mean_restricted_cost": float(restricted_cost.mean()),
        "mean_actual_spent": float(actual_cost.mean()),
        "median_first_cert_n": float(np.median(cert_n[certified])) if certified.any() else None,
        "certified_before_sufficient_n": int(np.count_nonzero(certified & (cert_n <= n_star))),
        "ever_missed_true_model": int(ever_missed_true_model.sum()),
        "ever_missed_q": int(ever_missed_q.sum()),
    }
    return summary, records


def bernoulli_kl(p: float, q: float) -> float:
    assert 0 < p < 1 and 0 < q < 1
    return float(p*math.log(p/q)+(1-p)*math.log((1-p)/(1-q)))


def binary_kl(p: float, q: float) -> float:
    return bernoulli_kl(p, q)


def e9_model() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    theta = np.array(E9_THETAS, dtype=float)
    means = np.stack((SENSOR_BASE+S*(theta[:,0]+theta[:,1]),
                      SENSOR_BASE+S*(theta[:,0]-theta[:,1])), axis=1)
    signs = np.sign(theta[:,0]-QSTAR).astype(int)
    assert np.all((means>0) & (means<1))
    assert np.all(signs != 0)
    return theta, means, signs


def info_lp(true_idx: int, means: np.ndarray, signs: np.ndarray):
    """Cost-normalized max-min KL LP, with separate grid verification."""
    opp = np.flatnonzero(signs != signs[true_idx])
    D = np.array([[bernoulli_kl(means[true_idx,e], means[j,e]) for e in range(2)]
                  for j in opp])
    result = linprog([0,0,-1], A_ub=np.column_stack((-D, np.ones(len(opp)))),
                     b_ub=np.zeros(len(opp)), A_eq=[[PRICES[0], PRICES[1], 0]],
                     b_eq=[1], bounds=[(0,None),(0,None),(0,None)], method="highs")
    if not result.success:
        raise RuntimeError(result.message)
    w = result.x[:2]
    value = float(np.min(D @ w))
    assert abs(value - result.x[2]) < 1e-8
    fractions = np.linspace(0, 1, 4001)
    grid = (D[:,0,None]*fractions[None,:]/PRICES[0]
            + D[:,1,None]*(1-fractions)[None,:]/PRICES[1])
    grid_max = float(np.max(np.min(grid, axis=0)))
    assert abs(value-grid_max) < 5e-5, (value, grid_max)
    sample_plus_prob = float(w[0]/(w[0]+w[1]))
    information_per_cost = value
    kl_target = binary_kl(1-BETA_ABS-DELTA, DELTA)
    return {
        "I_star": information_per_cost,
        "cost_lower_bound": kl_target/information_per_cost,
        "oracle_w_plus": float(w[0]), "oracle_w_minus": float(w[1]),
        "oracle_cost_fraction_plus": float(w[0]*PRICES[0]),
        "oracle_cost_fraction_minus": float(w[1]*PRICES[1]),
        "oracle_sample_prob_plus": sample_plus_prob,
        "brute_grid_I": grid_max,
        "opposite_models": [int(i) for i in opp],
        "kl_by_opposite": D.tolist(),
    }


def e9_cell(true_idx: int, policy: str, R: int, seed: int,
            batch: int, budget: float, oracle_fractions: list[float]):
    """Multihypothesis likelihood-ratio confidence sets with optional stopping."""
    theta, means, signs = e9_model()
    HYP = len(theta)
    true_sign = signs[true_idx]
    rng = np.random.default_rng(seed)
    ll = np.zeros((R, HYP), dtype=float)
    n = np.zeros((R, 2), dtype=int)
    spent = np.zeros(R, dtype=float)
    signed = np.zeros(R, dtype=int)
    ever_true_excluded = np.zeros(R, dtype=bool)
    log_p = np.log(means)
    log_1mp = np.log1p(-means)
    threshold = math.log((HYP-1)/DELTA)
    max_rounds = math.ceil(budget/(batch*min(PRICES)))+1
    for t in range(max_rounds):
        active = np.flatnonzero((signed == 0) & (spent + batch*min(PRICES) <= budget + 1e-10))
        if not len(active):
            break
        if policy == "static_plus":
            choices = np.zeros(len(active), dtype=int)
        elif policy == "static_minus":
            choices = np.ones(len(active), dtype=int)
        elif policy == "uniform":
            choices = np.full(len(active), t % 2, dtype=int)
        elif policy == "pooled_mix":
            # Predeclared design: model-wise oracle fractions averaged *before*
            # sampling; the unknown true model is never used to choose a channel.
            pooled_plus = float(np.mean(oracle_fractions))
            choices = (rng.random(len(active)) >= pooled_plus).astype(int)
        elif policy == "adaptive":
            mle = np.argmax(ll[active], axis=1)
            probs = np.asarray(oracle_fractions)[mle]
            choices = (rng.random(len(active)) >= probs).astype(int)
            if (t+1) % 8 == 0:
                choices = np.argmin(n[active], axis=1)
        else:
            raise ValueError(policy)
        affordable = spent[active] + batch*PRICES[choices] <= budget + 1e-10
        active, choices = active[affordable], choices[affordable]
        if not len(active):
            continue
        for e in range(2):
            idx = active[choices == e]
            if not len(idx):
                continue
            obs = rng.binomial(batch, means[true_idx,e], size=len(idx))
            ll[idx] += obs[:,None]*log_p[None,:,e] + (batch-obs[:,None])*log_1mp[None,:,e]
            n[idx,e] += batch
            spent[idx] += batch*PRICES[e]
        # Bonferroni/Ville: exclude theta only if some model exceeds
        # its likelihood by (|Theta|-1)/delta, valid at all stopping times.
        evidence_gap = np.max(ll[active], axis=1, keepdims=True) - ll[active]
        keep = evidence_gap < threshold
        assert np.all(keep.any(axis=1))
        ever_true_excluded[active] |= ~keep[:,true_idx]
        pos_remaining = np.any(keep & (signs[None,:] > 0), axis=1)
        neg_remaining = np.any(keep & (signs[None,:] < 0), axis=1)
        sign_now = np.where(pos_remaining & ~neg_remaining, 1,
                            np.where(neg_remaining & ~pos_remaining, -1, 0))
        signed[active[sign_now != 0]] = sign_now[sign_now != 0]
    did_sign = signed != 0
    wrong = did_sign & (signed != true_sign)
    assert not np.any(wrong & (~ever_true_excluded))
    restricted_cost = np.where(did_sign, spent, budget)
    records = []
    for i in range(R):
        records.append({
            "replicate": i, "seed": seed, "true_index": true_idx,
            "q": float(theta[true_idx,0]), "h": float(theta[true_idx,1]),
            "policy": policy, "signed_status": int(signed[i]),
            "correct_sign": int(true_sign), "certified": int(did_sign[i]),
            "wrong_sign": int(wrong[i]), "actual_spent": float(spent[i]),
            "restricted_cost": float(restricted_cost[i]),
            "n_plus": int(n[i,0]), "n_minus": int(n[i,1]),
            "ever_excluded_true_model": int(ever_true_excluded[i]),
        })
    summary = {
        "experiment": "E9", "true_index": true_idx, "q": float(theta[true_idx,0]),
        "h": float(theta[true_idx,1]), "R": R, "batch": batch, "budget": budget,
        "policy": policy, "true_sign": int(true_sign),
        "certified": int(did_sign.sum()), "certified_rate": float(did_sign.mean()),
        "certified_wilson95": wilson(int(did_sign.sum()),R),
        "wrong": int(wrong.sum()), "wrong_rate": float(wrong.mean()),
        "wrong_wilson95": wilson(int(wrong.sum()),R),
        "mean_actual_spent": float(np.mean(spent)),
        "mean_restricted_cost": float(np.mean(restricted_cost)),
        "mean_cost_signed_only": float(np.mean(spent[did_sign])) if did_sign.any() else None,
        "ever_excluded_true_model": int(ever_true_excluded.sum()),
    }
    return summary, records


def run_all(quick: bool, verify_only: bool) -> Path:
    folder = BASE / ("results_quick" if quick else "results")
    if verify_only:
        verify_all(folder)
        return folder
    folder.mkdir(exist_ok=True)
    cfg = {"quick":quick,"delta":DELTA,"beta_abs":BETA_ABS,
           "e7_n":E7_NS,"e7_channels":E7_CHANNELS,
           "e8_worlds":E8_WORLDS,"e9_thetas":E9_THETAS,"e9_policies":E9_POLICIES,
           "repetitions": {"E7":40 if quick else 1000,
                           "E8":20 if quick else 400,
                           "E9":15 if quick else 300},
           "batch_E8":1000,"batch_E9":100,
           "e9_max_budget":30000 if quick else 80000,
           "base_seed":20261024,"source_sha256":source_fingerprint(),
           "scm":"Original finite-branch model; q_star=0.3; linked offset sensor"}
    dump_json(folder/"design.json",cfg)
    rows7, reps7 = [],[]
    for ci, channel in enumerate(E7_CHANNELS):
        for ni,n in enumerate(E7_NS):
            for qi,q in enumerate((.25,.35)):
                seed = 20261024 + 200_000 + ci*10007 + ni*997 + qi*17
                name = f"{channel}_n{n}_q{q:.2f}"
                args = {"channel":channel, "n":n, "q":q, "R":cfg["repetitions"]["E7"],
                        "seed":seed}
                s, rec, cached = run_cached("E7",name,args,folder,e7_cell)
                rows7.append(s);reps7.extend(rec)
                print(f"E7 {name}: signed {s['certified']}/{s['R']} wrong {s['certified_wrong']} "
                      f"{'cached' if cached else 'ran'}",flush=True)
    dump_csv(folder/"e7_summary.csv",rows7)
    dump_csv(folder/"e7_replicates.csv",reps7)
    rows8,reps8=[],[]
    max_nstar=max(separation_threshold(S*abs(q-QSTAR)) for q,h in E8_WORLDS)
    common_cap_n=math.ceil((max_nstar+2*cfg["batch_E8"])/cfg["batch_E8"])*cfg["batch_E8"]
    for wi,(q,h) in enumerate(E8_WORLDS):
        seed=20261024 + 400_000 + wi*10007
        name=f"q{q:.2f}_h{h:+.2f}".replace("+","p").replace("-","m")
        args={"q":q,"h":h,"R":cfg["repetitions"]["E8"],
              "seed":seed,"batch":cfg["batch_E8"],"common_cap_n":common_cap_n}
        s,rec,cached=run_cached("E8",name,args,folder,e8_cell)
        rows8.append(s);reps8.extend(rec)
        print(f"E8 {name}: n*={s['n_sufficient_per_channel']} "
              f"signed {s['certified']}/{s['R']} wrong {s['wrong']} "
              f"{'cached' if cached else 'ran'}",flush=True)
    dump_csv(folder/"e8_summary.csv",rows8)
    dump_csv(folder/"e8_replicates.csv",reps8)
    theta,means,signs=e9_model()
    info=[info_lp(i,means,signs) for i in range(len(theta))]
    infos=[{"theta":i,"q":float(theta[i,0]),"h":float(theta[i,1]),
            "sign":int(signs[i]),**entry} for i,entry in enumerate(info)]
    dump_json(folder/"e9_oracle_information.json",infos)
    oracle_p=[it["oracle_sample_prob_plus"] for it in info]
    rows9,reps9=[],[]
    for ti in range(len(theta)):
        for pi,policy in enumerate(E9_POLICIES):
            seed=20261024 + 600_000 + ti*10007 + pi*997
            name=f"theta{ti}_{policy}"
            args={"true_idx":ti, "policy":policy, "R":cfg["repetitions"]["E9"],
                  "seed":seed,"batch":cfg["batch_E9"],"budget":cfg["e9_max_budget"],
                  "oracle_fractions":oracle_p}
            s,rec,cached=run_cached("E9",name,args,folder,e9_cell)
            s.update({"I_star":info[ti]["I_star"],
                      "cost_lower_bound_conditional":info[ti]["cost_lower_bound"],
                      "oracle_cost_fraction_plus":info[ti]["oracle_cost_fraction_plus"]})
            rows9.append(s);reps9.extend(rec)
            print(f"E9 {name}: signed {s['certified']}/{s['R']} wrong {s['wrong']}, "
                  f"restricted {s['mean_restricted_cost']:.1f} "
                  f"{'cached' if cached else 'ran'}",flush=True)
    dump_csv(folder/"e9_summary.csv",rows9)
    dump_csv(folder/"e9_replicates.csv",reps9)
    compare_legacy(folder)
    verify_all(folder)
    print("ALL COMPLETED",flush=True)
    return folder


def compare_legacy(folder: Path) -> None:
    """Record comparable observables while retaining design differences."""
    original = BASE/"historical_source"/"results"
    old_dynamic=json.loads((original/"dynamic_summary.json").read_text())
    old_static=json.loads((original/"summary.json").read_text())
    new_e9=read_csv(folder/"e9_summary.csv")
    match=[]
    for key,cell in old_dynamic["cells"].items():
        if cell.get("allocation") not in ("witness","uniform"):
            continue
        q=float(cell["q"]);h=float(cell["h"])
        same=[r for r in new_e9 if abs(float(r["q"])-q)<1e-10
              and abs(float(r["h"])-h)<1e-10
              and r["policy"] in ("adaptive","uniform")]
        for r in same:
            match.append({
                "q":q,"h":h,"old_allocation":cell["allocation"],
                "old_R":cell["R"],"old_budget":cell["budget"],
                "old_sign_rate":cell["signed"]/cell["R"],
                "old_restricted_cost":cell["restricted_cost"],
                "new_allocation":r["policy"],"new_R":r["R"],
                "new_budget":r["budget"],
                "new_sign_rate":r["certified_rate"],
                "new_restricted_cost":r["mean_restricted_cost"],
                "comparison_validity":"DESCRIPTIVE ONLY: same q,h and sensor laws; "
                                      "different model classes, rules and budget",
            })
    if match:
        dump_csv(folder/"comparison_legacy_matching_worlds.csv",match)
    dump_json(folder/"historical_reference.json",{
        "original_source":"historical_source/results/summary.json and dynamic_summary.json",
        "original_replicate_count":len(read_csv(original/"replicates.csv")),
        "original_dynamic_replicate_count":len(read_csv(original/"dynamic_replicates.csv")),
        "original_static_R":old_static.get("R"),
        "original_dynamic_R":old_dynamic.get("R"),
        "match_rows":len(match),
        "caveat":"Exact q,h may match, but finite-grid likelihood certificates in E9 "
                 "and original continuous (q,h) confidence sets are different inference tasks."
    })


def verify_all(folder: Path):
    assert folder.exists(), folder
    cfg = json.loads((folder/"design.json").read_text())
    for phase in ("e7","e8","e9"):
        summ=read_csv(folder/f"{phase}_summary.csv")
        reps=read_csv(folder/f"{phase}_replicates.csv")
        assert summ and reps
        expected=sum(int(float(r["R"])) for r in summ)
        assert len(reps)==expected,(phase,len(reps),expected)
        assert all(int(float(r["wrong_sign"])) in (0,1) for r in reps if "wrong_sign" in r)
    summ8=read_csv(folder/"e8_summary.csv")
    for s in summ8:
        k=float(s["kappa_lp"])
        nstar=int(s["n_sufficient_per_channel"])
        assert 2*positive_radius(nstar)<k
        assert nstar==1 or 2*positive_radius(nstar-1)>=k
        assert abs(k-float(s["kappa_formula"]))<1e-8
        assert int(s["wrong"])<=int(s["ever_missed_true_model"])
    summ9=read_csv(folder/"e9_summary.csv")
    for s in summ9:
        assert int(s["wrong"])<=int(s["ever_excluded_true_model"])
        assert float(s["I_star"])>0 and float(s["cost_lower_bound_conditional"])>0
    information=json.loads((folder/"e9_oracle_information.json").read_text())
    for d in information:
        assert abs(d["oracle_w_plus"]*PRICES[0]+d["oracle_w_minus"]*PRICES[1]-1)<1e-8
        assert d["I_star"]>0
        assert abs(d["I_star"]-d["brute_grid_I"])<5e-5
    print(f"VERIFIED {folder.name}: R(E7/E8/E9)="
          f"{cfg['repetitions']['E7']}/{cfg['repetitions']['E8']}/{cfg['repetitions']['E9']}",
          flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick",action="store_true",help="small independent smoke study")
    parser.add_argument("--verify-only",action="store_true",help="verify existing output files")
    args=parser.parse_args()
    run_all(args.quick,args.verify_only)


if __name__=="__main__":
    main()
