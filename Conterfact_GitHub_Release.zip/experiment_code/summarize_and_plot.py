#!/usr/bin/env python3
"""Recompute the E7--E9 report and plots from saved simulation CSV/JSON files."""
from __future__ import annotations
import csv
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"results"
FIGS=ROOT/"figures"
FIGS.mkdir(exist_ok=True)


def read_csv(path):
    with path.open(newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row,key):
    return float(row[key])


def fmt(x,d=1):
    return f"{x:,.{d}f}"


def summary_e7(rows):
    by=defaultdict(list)
    for r in rows:
        by[(r["channel"],int(r["n"]))].append(r)
    names=["factual","uninformative_proxy","weak_proxy","strong_proxy"]
    fig,ax=plt.subplots(figsize=(7.4,4.6))
    colors={"factual":"#777777","uninformative_proxy":"#b75b51",
            "weak_proxy":"#2f82a3","strong_proxy":"#29834a"}
    for name in names:
        nn=sorted({n for ch,n in by if ch==name})
        yy=[np.mean([f(t,"certified_rate") for t in by[(name,n)]]) for n in nn]
        ax.plot(nn,yy,"o-",color=colors[name],label=name.replace("_"," "))
    ax.set(xscale="log",xlabel="Independent samples per experiment",
           ylabel="Unconditional certified-sign probability",
           title="E7: sign certificates require sign-informative evidence",ylim=(-.02,1.05))
    ax.grid(alpha=.2);ax.legend(loc="center right",fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e7_certification.png",dpi=195);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.4,4.1))
    for name in names:
        nn=sorted({n for ch,n in by if ch==name})
        yy=[np.mean([f(t,"forced_wrong_rate") for t in by[(name,n)]]) for n in nn]
        ax.plot(nn,yy,"o-",color=colors[name],label=name.replace("_"," "))
    ax.set(xscale="log",xlabel="Samples per experiment",ylabel="Forced-decision error rate",
           title="E7: noninformative channels cannot discriminate signs",ylim=(-.02,.61))
    ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e7_forced_error.png",dpi=195);plt.close(fig)
    out=[]
    for name in names:
        for n in sorted({n for ch,n in by if ch==name}):
            b=by[(name,n)]
            out.append({"channel":name,"n":n,"R_total":sum(int(r["R"]) for r in b),
                        "certificate_rate":np.mean([f(r,"certified_rate") for r in b]),
                        "forced_error_rate":np.mean([f(r,"forced_wrong_rate") for r in b]),
                        "certified_wrong":sum(int(r["certified_wrong"]) for r in b),
                        "g":f(b[0],"g"),
                        "theorem_sufficient_n":b[0]["theorem_A_n_sufficient"]})
    return out


def summary_e8(rows):
    ordered=sorted(rows,key=lambda r:(f(r,"kappa_lp"),f(r,"q")))
    fig,ax=plt.subplots(figsize=(7.2,4.4))
    xx=[f(r,"kappa_lp") for r in ordered]
    yy=[f(r,"median_first_cert_n") for r in ordered]
    nn=[f(r,"n_sufficient_per_channel") for r in ordered]
    ax.scatter(xx,yy,s=58,label="Empirical median first-sign samples/channel",color="#236c9e")
    ax.scatter(xx,nn,s=45,marker="x",label="Theorem sufficient samples/channel",color="#bc5e40")
    ax.set(yscale="log",xlabel=r"Observable separation $\kappa$",
           ylabel="Samples per sensor (log scale)",
           title="E8: sufficient certification threshold vs observed stopping")
    ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e8_certification_threshold.png",dpi=195);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.2,4.1))
    ax.scatter(xx,[f(r,"mean_restricted_cost") for r in ordered],s=54,
               color="#236c9e",label="Observed restricted mean cost")
    ax.scatter(xx,[f(r,"cost_sufficient_bound") for r in ordered],s=46,
               marker="x",color="#bc5e40",label="Deterministic sufficient cost")
    ax.set(yscale="log",xlabel=r"Observable separation $\kappa$",
           ylabel="Synthetic cost units (log scale)",
           title="E8: costs increase as opposite-sign models approach")
    ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e8_cost_separation.png",dpi=195);plt.close(fig)
    return [{"q":f(r,"q"),"h":f(r,"h"),"kappa":f(r,"kappa_lp"),
             "n_sufficient":int(r["n_sufficient_per_channel"]),
             "median_n":f(r,"median_first_cert_n"),
             "certified":int(r["certified"]),"R":int(r["R"]),
             "wrong":int(r["wrong"]),"mean_restricted_cost":f(r,"mean_restricted_cost"),
             "cost_sufficient":f(r,"cost_sufficient_bound"),
             "full_model_coverage_failures":int(r["ever_missed_true_model"])}
            for r in ordered]


def stratified_means_costs(reps):
    groups=defaultdict(list)
    for r in reps:
        groups[(r["policy"],int(r["true_index"]))].append(f(r,"restricted_cost"))
    results={}
    for policy in sorted({p for p,t in groups}):
        v=[np.asarray(groups[(policy,i)],dtype=float) for i in range(8)]
        mu=float(np.mean([a.mean() for a in v]))
        se=math.sqrt(sum(float(np.var(a,ddof=1))/len(a) for a in v))/len(v)
        results[policy]={"balanced_mean_restricted_cost":mu,"balanced_se":se,
                         "per_model_means":[float(a.mean()) for a in v],
                         "per_model_R":[len(a) for a in v]}
    return results


def summary_e9(rows,reps):
    se=stratified_means_costs(reps)
    groups=defaultdict(list)
    for r in rows:
        groups[r["policy"]].append(r)
    res=[]
    for policy in ("adaptive","uniform","pooled_mix","static_plus","static_minus"):
        b=groups[policy]
        record={"policy":policy,"R_total":sum(int(r["R"]) for r in b),
                "certified":sum(int(r["certified"]) for r in b),
                "wrong":sum(int(r["wrong"]) for r in b),
                "ever_excluded_true_model":sum(int(r["ever_excluded_true_model"]) for r in b),
                **se[policy]}
        record["certified_rate"]=record["certified"]/record["R_total"]
        record["wrong_rate"]=record["wrong"]/record["R_total"]
        res.append(record)
    cost={r["policy"]:r["balanced_mean_restricted_cost"] for r in res}
    results_by={(int(r["true_index"]),r["policy"]):r for r in rows}
    fig,ax=plt.subplots(figsize=(9.3,4.9))
    models=range(8);width=.175
    colors=["#196e9e","#d98736","#6e9c82","#a05252","#805f97"]
    for pidx,policy in enumerate(("adaptive","uniform","pooled_mix","static_plus","static_minus")):
        yy=[f(results_by[(i,policy)],"mean_restricted_cost") for i in models]
        xx=np.array(list(models))+(pidx-2)*width
        ax.bar(xx,yy,width,label=policy.replace("_"," "),color=colors[pidx])
    ax.set(xticks=list(models),xticklabels=[f"$\\theta_{i}$" for i in models],
           yscale="log",ylabel="Restricted mean cost (log scale)",
           xlabel="True finite-grid structural model",
           title="E9: model-dependent cost and failure of single-channel identification")
    ax.grid(axis="y",alpha=.2);ax.legend(ncol=3,fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e9_restricted_cost_by_model.png",dpi=195);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8.2,4.0))
    for policy,color in (("adaptive","#196e9e"),("uniform","#d98736"),
                         ("pooled_mix","#6e9c82"),("static_plus","#a05252"),
                         ("static_minus","#805f97")):
        abst=[1-f(results_by[(i,policy)],"certified_rate") for i in models]
        ax.plot(list(models),abst,"o-",label=policy.replace("_"," "),color=color)
    ax.set(xticks=list(models),ylim=(-.025,1.05),xlabel="True model index",
           ylabel="Budget-censored abstention probability",
           title="E9: single-sensor nonidentifiability persists with large sample caps")
    ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e9_abstention_by_model.png",dpi=195);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8.3,4.2))
    ordered=("adaptive","uniform","pooled_mix")
    indices=np.arange(8)
    for pidx,policy in enumerate(ordered):
        ratios=[f(results_by[(i,policy)],"mean_restricted_cost")/
                f(results_by[(i,policy)],"cost_lower_bound_conditional") for i in models]
        ax.plot(indices,ratios,"o-",label=policy.replace("_"," "))
    ax.axhline(1,color="black",ls=":",lw=.9)
    ax.set(xticks=list(models),xlabel="True model index",
           ylabel="Observed restricted cost / conditional cost lower bound",
           title="E9: descriptive only; bound requires uniform abstention <= 0.10")
    ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(FIGS/"e9_cost_vs_conditional_lower_bound.png",dpi=195)
    plt.close(fig)
    # For a balanced comparison, policy cells use independent random streams.
    dif=cost["uniform"]-cost["adaptive"]
    sd=math.sqrt(se["uniform"]["balanced_se"]**2+se["adaptive"]["balanced_se"]**2)
    return res,{"uniform_minus_adaptive_cost":dif,
                "relative_saving_vs_uniform":dif/cost["uniform"],
                "difference_se_unpaired":sd,
                "normal_approx_95":(dif-1.96*sd,dif+1.96*sd),
                "caveat":"Independent policy replicates; exploratory, unadjusted normal CI; "
                         "synthesis is balanced over eight *synthetic* model worlds."}


def report(e7,e8,e9,comparison,infos,legacy):
    e7index={(r["channel"],r["n"]):r for r in e7}
    texts=[]
    texts.append("# E7-E9: Evidence sufficiency and costed sign certification\n")
    texts.append("Executed synthetic experiments accompanying *Decision Certificates for Cross-World Utilities "
                 "in Finite-Horizon Policies*. The results below were generated from saved replicate-level records.\n")
    texts.append("## Experimental setting\n")
    texts.append("- **Underlying SCM:** the original irreversibly branched two-potential-outcome model. "
                 "For the fixed candidate/reference policies, the gap has the sign of `q - 0.3`; "
                 "all original model constants and the two linked-offset sensor laws are reused.\n"
                 "- **Available observations:** per purchased unit, only a single-world factual feature "
                 "or binary proxy observation is disclosed. No paired latent `(Y0,Y1)` label is available to a learner.\n"
                 "- **Error/abstention:** nominal sign error level `delta=0.05`; "
                 "the composite lower bound is stated for hypothetical rules satisfying both "
                 "`delta=0.05` and `beta_abs=0.10` *uniformly* over the full finite model class.\n"
                 "- **Replications:** E7 1,000 per cell (32 cells), E8 400 per cell (6 cells), "
                 "E9 300 per cell (40 cells). Random seeds, scripts, and raw records are in the archive.\n")
    texts.append("## E7: a sign-informative evidence channel is necessary\n")
    texts.append("Here `Theta={q=0.25,q=0.35}`. Factual `Y1` and an uninformative proxy have the same "
                 "observation laws in both models. The weak proxy uses `alpha=beta=0.7`, the strong proxy "
                 "uses `alpha=beta=0.9`. A forced decision classifies the sample mean against the "
                 "model midpoint; a conservative fixed-sample certificate issues a sign only when a "
                 "Hoeffding interval excludes the midpoint.\n")
    texts.append("| Channel | Per-model mean gap g | Theorem sufficient n | Certified at n=5,000 | Certified at n=20,000 | Forced error at n=20,000 |\n"
                 "|---|---:|---:|---:|---:|---:|\n")
    for name in ("factual","uninformative_proxy","weak_proxy","strong_proxy"):
        a=e7index[(name,5000)];b=e7index[(name,20000)]
        req=a["theorem_sufficient_n"]
        texts.append(f"| {name} | {a['g']:.3f} | {req if req else 'not finite'} | "
                     f"{a['certificate_rate']:.3f} | {b['certificate_rate']:.3f} | "
                     f"{b['forced_error_rate']:.3f} |\n")
    texts.append("\nThe noninformative channels produced no valid signs at any studied sample size; "
                 "a forced randomized sign stayed near 50% error. For the informative channels, "
                 "certification increased with sample size. All E7 sign certificates recorded zero wrong "
                 "signs; that finite observation does not prove a zero error probability. "
                 "Theorem's sufficient `n` is conservative, rather than an observed threshold.\n")
    texts.append("![](../figures/e7_certification.png)\n\n![](../figures/e7_forced_error.png)\n")
    texts.append("## E8: geometric separation and sufficient stopping time\n")
    texts.append("The structural class is `q in [0.2,0.4]`, `h in [-0.06,0.06]` and the observable "
                 "features are the two original linked-offset Bernoulli sensor means "
                 "`m_plus=0.08+0.8(q+h)`, `m_minus=0.08+0.8(q-h)`. The opposite-sign set is "
                 "`q<=0.3` or `q>=0.3`. An independent LP gives "
                 "`kappa = 0.8*abs(q-0.3)`. The stated `n_star` is the *smallest integer* "
                 "satisfying `2*r_n < kappa`; it is a sufficient per-sensor sample size, "
                 "not a minimax or expected-time bound.\n")
    texts.append("| q | h | kappa | Theorem n_star | Median observed n | Certified / 400 | Wrong |\n"
                 "|---:|---:|---:|---:|---:|---:|---:|\n")
    for r in sorted(e8,key=lambda x:x["q"]):
        texts.append(f"| {r['q']:.2f} | {r['h']:+.2f} | {r['kappa']:.3f} | "
                     f"{r['n_sufficient']:,} | {int(r['median_n']):,} | "
                     f"{r['certified']}/400 | {r['wrong']} |\n")
    texts.append("\nAll 2,400 E8 runs certified within the shared cap, with no observed wrong signs. "
                 "The earlier empirical stop than `n_star` is consistent with `n_star` being sufficient. "
                 "No coverage-preserving path failed to certify by its separation threshold. "
                 "Both signs were evaluated. The cap was common across all models, and the learner "
                 "used neither the true `q,h` nor its `kappa` to select observations.\n")
    texts.append("![](../figures/e8_certification_threshold.png)\n\n![](../figures/e8_cost_separation.png)\n")
    texts.append("## E9: composite alternatives and evidence-cost allocation\n")
    texts.append("The finite class contains eight models: `q in {0.25,0.28,0.32,0.35}` and "
                 "`h in {-0.05,+0.05}`. Each of five strategies faces the same model menu and sensor prices "
                 "`(1,1.6)`, with a common maximum expenditure of 80,000. "
                 "The sign decision is made using an anytime likelihood-ratio confidence set, "
                 "with threshold `log((|Theta|-1)/delta)`. The adaptive strategy uses past "
                 "likelihoods and periodic exploration; pooled-mix weights are frozen before data. "
                 "The true-model-specific LP weights are *only* an information lower-bound benchmark "
                 "and are never used by a deployed comparator.\n")
    texts.append("| Allocation | Certificates / 2,400 | Wrong / 2,400 | Balanced restricted mean cost | Across-model SE |\n"
                 "|---|---:|---:|---:|---:|\n")
    for r in e9:
        texts.append(f"| {r['policy']} | {r['certified']:,}/2,400 | {r['wrong']}/2,400 | "
                     f"{fmt(r['balanced_mean_restricted_cost'])} | {fmt(r['balanced_se'])} |\n")
    texts.append("\nThe balanced eight-model restricted mean for adaptive allocation was "
                 f"{fmt(next(r for r in e9 if r['policy']=='adaptive')['balanced_mean_restricted_cost'])} "
                 "cost units, compared with "
                 f"{fmt(next(r for r in e9 if r['policy']=='uniform')['balanced_mean_restricted_cost'])} "
                 "for alternating uniform allocation. The unpaired difference, uniform minus adaptive, "
                 f"was {fmt(comparison['uniform_minus_adaptive_cost'])} "
                 f"({100*comparison['relative_saving_vs_uniform']:.1f}% of the uniform mean); "
                 "the exploratory, unadjusted 95% normal approximation across eight fixed worlds was "
                 f"[{fmt(comparison['normal_approx_95'][0])}, "
                 f"{fmt(comparison['normal_approx_95'][1])}]. "
                 "Results are *not uniformly favorable*: individual model cells can reverse the ranking. "
                 "Single-sensor strategies suffered large abstention rates in worlds for which an "
                 "opposite-sign model has the same selected sensor law.\n")
    texts.append("![](../figures/e9_restricted_cost_by_model.png)\n\n"
                 "![](../figures/e9_abstention_by_model.png)\n")
    texts.append("### Interpretation of the cost lower bound\n")
    texts.append("For each true model `theta`, the oracle information LP computes "
                 "`I_star(theta)` using KL divergences against *all* opposite-sign alternatives. "
                 "The benchmark `kl(1-beta_abs-delta,delta)/I_star(theta)` applies to a procedure "
                 "only when it meets the required error and abstention limits **uniformly over the "
                 "full hypothesis class**. Empirical sign rates of 300/300 cannot establish a "
                 "uniform `beta_abs<=0.10` guarantee, and some single-sensor strategies "
                 "plainly violate that prerequisite. Thus the plotted ratio is descriptive; "
                 "it is not a formal efficiency ratio or proof of bound attainment. "
                 "The cost LP was independently checked against a dense one-dimensional "
                 "cost-fraction grid for each true model.\n")
    texts.append("![](../figures/e9_cost_vs_conditional_lower_bound.png)\n")
    texts.append("## Comparison with the earlier executed study\n")
    texts.append("The original archive contains "
                 f"{legacy['original_replicate_count']:,} E1-E6 replicate records and "
                 f"{legacy['original_dynamic_replicate_count']:,} composite-allocation records. "
                 "E9 deliberately reuses their joint-offset Bernoulli sensor mechanism, selected "
                 "truths, and unit prices. `results/comparison_legacy_matching_worlds.csv` "
                 "shows both data sets side by side for matching `(q,h)`. "
                 "**The costs are not directly comparable as improvements:** the previous "
                 "study uses a continuous feasible `(q,h)` set, a different confidence rule "
                 "and a 400,000 cap; E9 uses a known *eight-point* hypothesis class, "
                 "likelihood-ratio certification and an 80,000 cap. Its lower numerical costs "
                 "do not demonstrate a better method for the previous problem.\n")
    texts.append("## Verification and limitations\n")
    texts.append("- Original source and output records are included unchanged under "
                 "`historical_source/`. Existing executable audit tools remain available.\n"
                 "- The new batch runner saves each completed condition separately; rerunning "
                 "uses matching source/configuration fingerprints to skip completed cells.\n"
                 "- Every replicate is present in E7--E9 CSV files and per-cell files. Counts "
                 "were reconciled with summary totals; LP identities, thresholds, "
                 "and the implication 'wrong certificate => coverage failure' were checked.\n"
                 "- All observations are synthetic or model-implied Bernoulli draws. "
                 "No human preference data, real cross-world sensor calibration, "
                 "unmodeled h drift or independent-machine replication is represented as completed.\n"
                 "- A formal significance claim about policy superiority would require "
                 "a predeclared primary contrast, multiplicity handling and broader model classes. "
                 "Neither finite simulations nor empirical rare-event counts establish "
                 "universal error probabilities.\n")
    texts.append("## Reproduction\n"
                 "```bash\n"
                 "python -m unittest discover -s experiment_code -p 'test_*.py' -v\n"
                 "python experiment_code/run_e7_e9.py --verify-only\n"
                 "python experiment_code/run_e7_e9.py\n"
                 "python experiment_code/summarize_and_plot.py\n"
                 "cd historical_source && python reproduce.py --verify\n"
                 "```\n")
    body="\n".join(texts).replace("![](../figures/", "![](figures/")
    # Joining prepared paragraphs inserts blank lines, which are incorrect
    # between rows of a single CommonMark table. Retain block boundaries.
    body=re.sub(r"(?m)^(\|[^\n]*\|)\n\n(?=\|)",r"\1\n",body)
    return body+"\n"


def main():
    e7=summary_e7(read_csv(DATA/"e7_summary.csv"))
    e8=summary_e8(read_csv(DATA/"e8_summary.csv"))
    e9,comparison=summary_e9(read_csv(DATA/"e9_summary.csv"),
                              read_csv(DATA/"e9_replicates.csv"))
    infos=json.loads((DATA/"e9_oracle_information.json").read_text())
    legacy=json.loads((DATA/"historical_reference.json").read_text())
    obj={"E7":e7,"E8":e8,"E9":e9,"E9_balanced_contrast":comparison,
         "historical_reference":legacy,"source":"actual executed replicate CSV"}
    (DATA/"analysis_summary.json").write_text(json.dumps(obj,indent=2)+"\n",encoding="utf-8")
    (ROOT/"EXPERIMENT_REPORT.md").write_text(
        report(e7,e8,e9,comparison,infos,legacy),encoding="utf-8")
    print("WROTE report and seven figures (two E7, two E8, three E9)")
    print("E9 unpaired cost difference",comparison["uniform_minus_adaptive_cost"])
    print("E9 approximate interval",comparison["normal_approx_95"])


if __name__=="__main__":
    main()
