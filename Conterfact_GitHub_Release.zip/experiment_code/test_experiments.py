#!/usr/bin/env python3
"""Independent invariant checks for the executed E7--E9 study."""
from __future__ import annotations

import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from run_e7_e9 import (
    DELTA, E9_THETAS, E9_POLICIES, QSTAR, S,
    e7_observable_mean, e7_cell, e8_lp_kappa, e8_cell,
    e9_model, e9_cell, info_lp, positive_radius, separation_threshold,
    bernoulli_kl,
    run_cached,
)
from model import gap
from dynamic_acquisition import radius, lp_reference


class ExperimentalTheoryTests(unittest.TestCase):
    def test_original_structural_gap(self):
        self.assertLess(gap(.25), 0.0)
        self.assertGreater(gap(.35), 0.0)
        self.assertAlmostEqual(gap(.30), 0.0, places=12)

    def test_factual_equivalence_and_proxy_identifiability(self):
        for channel, wanted in (
            ("factual", 0.0),
            ("uninformative_proxy", 0.0),
            ("weak_proxy", .04),
            ("strong_proxy", .08),
        ):
            g = abs(e7_observable_mean(channel,.35)-e7_observable_mean(channel,.25))
            self.assertAlmostEqual(g,wanted,places=12)

    def test_e7_certification_is_coverage_safe(self):
        for channel in ("uninformative_proxy","strong_proxy"):
            s,records=e7_cell(channel,2000,.25,100,8024031)
            self.assertEqual(len(records),100)
            self.assertEqual(s["certified_wrong"],0)
            if channel=="uninformative_proxy":
                self.assertEqual(s["certified"],0)

    def test_geometric_margin_with_lp(self):
        for q in (.215,.24,.28,.32,.34,.385):
            for h in (-.05,.0,.05):
                self.assertAlmostEqual(e8_lp_kappa(q,h),S*abs(q-QSTAR),places=8)

    def test_conservative_threshold_and_radius(self):
        for kappa in (.016,.04,.064):
            n=separation_threshold(kappa)
            self.assertTrue(2*positive_radius(n)<kappa)
            self.assertTrue(n==1 or 2*positive_radius(n-1)>=kappa)
            rs=radius(np.array([[n,n]]),m=2,delta=DELTA)
            self.assertAlmostEqual(float(rs[0,0]),positive_radius(n),places=12)

    def test_linked_offset_projection_independently(self):
        # Original archive's SciPy LP is independent of its algebraic projection.
        low, high=lp_reference([1000,1000,344,264])
        self.assertLessEqual(low,.28)
        self.assertGreaterEqual(high,.28)

    def test_e8_short_smoke(self):
        q,h=.35,.05
        ns=separation_threshold(S*abs(q-QSTAR))
        cap=int(math.ceil((ns+2000)/1000)*1000)
        s,rows=e8_cell(q,h,10,117,1000,cap)
        self.assertEqual(len(rows),10)
        self.assertEqual(s["wrong"],0)
        self.assertGreater(s["certified"],0)

    def test_kl_and_information_lp(self):
        theta,means,signs=e9_model()
        self.assertEqual(len(E9_THETAS),8)
        self.assertAlmostEqual(bernoulli_kl(.3,.3),0.0,places=12)
        for idx in range(len(theta)):
            d=info_lp(idx,means,signs)
            self.assertGreater(d["I_star"],0)
            self.assertAlmostEqual(d["I_star"],d["brute_grid_I"],delta=5e-5)
        # A sign-opposite pair can be indistinguishable on one sensor.
        # theta1=(.25,+.05), theta6=(.35,-.05).
        self.assertNotEqual(signs[1],signs[6])
        self.assertAlmostEqual(means[1,0],means[6,0],places=12)
        self.assertNotAlmostEqual(means[1,1],means[6,1],places=7)

    def test_implementable_policy_list_has_no_true_oracle(self):
        self.assertNotIn("oracle",E9_POLICIES)
        theta,means,signs=e9_model()
        p=[info_lp(i,means,signs)["oracle_sample_prob_plus"] for i in range(len(theta))]
        for policy in E9_POLICIES:
            s,rows=e9_cell(1,policy,8,9000001,100,15000,p)
            self.assertEqual(len(rows),8)
            self.assertLessEqual(s["wrong"],s["ever_excluded_true_model"])

    def test_checkpoint_names_do_not_collapse_decimal_parameters(self):
        # Regression for pathlib.with_suffix('.csv') silently dropping '.25'.
        with tempfile.TemporaryDirectory() as dirname:
            folder=Path(dirname)
            for q in (.25,.35):
                key=f"factual_n250_q{q:.2f}"
                params={"channel":"factual","n":250,"q":q,"R":5,"seed":923}
                _,rows,cached=run_cached("E7",key,params,folder,e7_cell)
                self.assertFalse(cached)
                self.assertEqual(len(rows),5)
            self.assertEqual(len(list((folder/"cells"/"E7").glob("*.csv"))),2)
            self.assertEqual(len(list((folder/"cells"/"E7").glob("*.json"))),2)
            for q in (.25,.35):
                key=f"factual_n250_q{q:.2f}"
                params={"channel":"factual","n":250,"q":q,"R":5,"seed":923}
                _,_,cached=run_cached("E7",key,params,folder,e7_cell)
                self.assertTrue(cached)


if __name__=="__main__":
    unittest.main(verbosity=2)
